"""
Feature Model Analysis Tool — GUI (Tkinter)
FAST NUCES — Formal Methods Project
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import tkinter.font as tkfont
from fm_core import FeatureModelParser, LogicTranslator, SATValidator, MWPGenerator, Feature
from typing import Optional
import threading


# ──────────────────────────────────────────────
#  COLOUR PALETTE
# ──────────────────────────────────────────────
BG        = "#0f1117"
PANEL     = "#1a1d27"
BORDER    = "#2a2d3a"
ACCENT    = "#6c8fff"
ACCENT2   = "#a78bfa"
GREEN     = "#4ade80"
RED       = "#f87171"
YELLOW    = "#fbbf24"
TEXT      = "#e2e8f0"
TEXT_DIM  = "#64748b"
FONT_MAIN = ("Consolas", 10)
FONT_HEAD = ("Consolas", 12, "bold")
FONT_BIG  = ("Consolas", 14, "bold")


class FeatureModelApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Feature Model Analysis Tool  —  FM Project")
        self.geometry("1280x800")
        self.configure(bg=BG)
        self.minsize(1000, 680)

        self.parser: Optional[FeatureModelParser] = None
        self.translator: Optional[LogicTranslator] = None
        self.validator: Optional[SATValidator] = None
        self.mwp_gen: Optional[MWPGenerator] = None

        # Feature checkboxes: name → BooleanVar
        self.check_vars: dict[str, tk.BooleanVar] = {}
        self.check_widgets: dict[str, ttk.Checkbutton] = {}
        self._suppress_callbacks = False

        self._build_ui()

    # ──────────────────────────────────────────
    #  UI CONSTRUCTION
    # ──────────────────────────────────────────

    def _build_ui(self):
        self._style()

        # ── Header ──
        hdr = tk.Frame(self, bg=PANEL, height=54)
        hdr.pack(fill="x", side="top")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="⬡  Feature Model Analysis Tool",
                 bg=PANEL, fg=ACCENT, font=("Consolas", 15, "bold")).pack(side="left", padx=20, pady=12)
        tk.Label(hdr, text="FAST NUCES — Formal Methods",
                 bg=PANEL, fg=TEXT_DIM, font=FONT_MAIN).pack(side="right", padx=20)

        # ── Toolbar ──
        bar = tk.Frame(self, bg=BORDER, height=1)
        bar.pack(fill="x")
        tb = tk.Frame(self, bg=BG, pady=8)
        tb.pack(fill="x", padx=16)
        self._btn(tb, "📂  Load XML File", self._load_file, ACCENT).pack(side="left", padx=4)
        self._btn(tb, "📋  Paste XML", self._paste_xml, ACCENT2).pack(side="left", padx=4)
        self._btn(tb, "✅  Validate Selection", self._validate_selection, GREEN).pack(side="left", padx=4)
        self._btn(tb, "🔢  Generate MWPs", self._generate_mwps, YELLOW).pack(side="left", padx=4)
        self._btn(tb, "🧹  Clear", self._clear_all, RED).pack(side="right", padx=4)

        # ── Main paned ──
        pane = tk.PanedWindow(self, orient="horizontal", bg=BG,
                              sashwidth=6, sashrelief="flat", bd=0)
        pane.pack(fill="both", expand=True, padx=10, pady=6)

        # Left: Feature Tree
        left = tk.Frame(pane, bg=PANEL, bd=0)
        pane.add(left, minsize=280)
        self._section_label(left, "FEATURE TREE")
        tree_wrap = tk.Frame(left, bg=PANEL)
        tree_wrap.pack(fill="both", expand=True, padx=8, pady=4)
        self.tree_canvas = tk.Canvas(tree_wrap, bg=PANEL, highlightthickness=0)
        tree_sb = ttk.Scrollbar(tree_wrap, orient="vertical", command=self.tree_canvas.yview)
        self.tree_canvas.configure(yscrollcommand=tree_sb.set)
        tree_sb.pack(side="right", fill="y")
        self.tree_canvas.pack(side="left", fill="both", expand=True)
        self.tree_inner = tk.Frame(self.tree_canvas, bg=PANEL)
        self.tree_canvas_window = self.tree_canvas.create_window(
            (0, 0), window=self.tree_inner, anchor="nw")
        self.tree_inner.bind("<Configure>", lambda e: self.tree_canvas.configure(
            scrollregion=self.tree_canvas.bbox("all")))
        self.tree_canvas.bind("<Configure>", lambda e: self.tree_canvas.itemconfig(
            self.tree_canvas_window, width=e.width))

        # Middle: Logic + Constraints
        mid = tk.Frame(pane, bg=PANEL, bd=0)
        pane.add(mid, minsize=320)
        self._section_label(mid, "PROPOSITIONAL LOGIC")
        self.logic_text = self._text_box(mid, height=14)
        self._section_label(mid, "CROSS-TREE CONSTRAINTS")
        self.constraint_text = self._text_box(mid, height=6)
        self._section_label(mid, "VALIDATION RESULT")
        self.valid_text = self._text_box(mid, height=8)

        # Right: MWPs
        right = tk.Frame(pane, bg=PANEL, bd=0)
        pane.add(right, minsize=280)
        self._section_label(right, "MINIMUM WORKING PRODUCTS")
        self.mwp_text = self._text_box(right, expand=True)

        # ── Status bar ──
        self.status_var = tk.StringVar(value="Ready — load an XML file to begin.")
        sb = tk.Label(self, textvariable=self.status_var,
                      bg=BORDER, fg=TEXT_DIM, font=FONT_MAIN,
                      anchor="w", padx=12, pady=4)
        sb.pack(fill="x", side="bottom")

    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("TCheckbutton", background=PANEL, foreground=TEXT,
                    font=FONT_MAIN, focuscolor=PANEL)
        s.map("TCheckbutton",
              foreground=[("active", ACCENT), ("disabled", TEXT_DIM)],
              background=[("active", PANEL)])
        s.configure("Vertical.TScrollbar", background=BORDER,
                    troughcolor=PANEL, bordercolor=PANEL, arrowcolor=TEXT_DIM)

    def _btn(self, parent, text, cmd, color):
        b = tk.Button(parent, text=text, command=cmd,
                      bg=PANEL, fg=color, font=FONT_MAIN,
                      relief="flat", padx=12, pady=5,
                      activebackground=BORDER, activeforeground=color,
                      cursor="hand2", bd=1, highlightthickness=1,
                      highlightbackground=color)
        return b

    def _section_label(self, parent, text):
        f = tk.Frame(parent, bg=BG, height=1)
        f.pack(fill="x", pady=(6, 0))
        tk.Label(parent, text=f"  {text}",
                 bg=BG, fg=ACCENT2, font=("Consolas", 9, "bold"),
                 anchor="w").pack(fill="x")
        tk.Frame(parent, bg=BORDER, height=1).pack(fill="x")

    def _text_box(self, parent, height=10, expand=False):
        t = scrolledtext.ScrolledText(parent, bg="#0d0f18", fg=TEXT,
                                       font=FONT_MAIN, relief="flat",
                                       height=height, padx=8, pady=8,
                                       insertbackground=ACCENT,
                                       selectbackground=ACCENT,
                                       wrap="word", state="disabled",
                                       bd=0)
        t.pack(fill="both", expand=expand, padx=8, pady=4)
        return t

    # ──────────────────────────────────────────
    #  ACTIONS
    # ──────────────────────────────────────────

    def _load_file(self):
        path = filedialog.askopenfilename(
            title="Open Feature Model XML",
            filetypes=[("XML files", "*.xml"), ("All files", "*.*")])
        if path:
            try:
                with open(path, "r") as f:
                    xml = f.read()
                self._process_xml(xml)
                self.status_var.set(f"Loaded: {path}")
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def _paste_xml(self):
        dlg = tk.Toplevel(self)
        dlg.title("Paste XML")
        dlg.configure(bg=BG)
        dlg.geometry("680x500")
        dlg.transient(self)
        tk.Label(dlg, text="Paste your XML below:",
                 bg=BG, fg=TEXT, font=FONT_MAIN).pack(padx=12, pady=8, anchor="w")
        t = scrolledtext.ScrolledText(dlg, bg="#0d0f18", fg=TEXT,
                                       font=FONT_MAIN, relief="flat",
                                       height=20, padx=8, pady=8)
        t.pack(fill="both", expand=True, padx=12)

        def submit():
            xml = t.get("1.0", "end").strip()
            if xml:
                try:
                    self._process_xml(xml)
                    dlg.destroy()
                    self.status_var.set("XML loaded from paste.")
                except Exception as e:
                    messagebox.showerror("Error", str(e))

        self._btn(dlg, "▶  Parse XML", submit, GREEN).pack(pady=10)

    def _process_xml(self, xml: str):
        self.parser = FeatureModelParser().parse(xml)
        self.translator = LogicTranslator(self.parser)
        self.validator = SATValidator(self.translator)
        self.mwp_gen = MWPGenerator(self.parser, self.validator)
        self._build_tree_ui()
        self._populate_logic()
        self._populate_constraints()
        self._clear_output(self.valid_text)
        self._clear_output(self.mwp_text)

    def _build_tree_ui(self):
        for w in self.tree_inner.winfo_children():
            w.destroy()
        self.check_vars.clear()
        self.check_widgets.clear()
        if self.parser and self.parser.root:
            self._render_feature(self.parser.root, self.tree_inner, depth=0, is_group_member=False)

    def _render_feature(self, feat: Feature, parent_widget, depth: int, is_group_member: bool):
        row = tk.Frame(parent_widget, bg=PANEL)
        row.pack(fill="x", padx=(depth * 18, 0), pady=1)

        # Type indicator
        if feat.parent is None:
            indicator = "◈"
            color = ACCENT
        elif feat.mandatory:
            indicator = "●"
            color = GREEN
        elif feat.group_type == "xor":
            indicator = "⊕"
            color = YELLOW
        elif feat.group_type == "or":
            indicator = "⊎"
            color = ACCENT2
        else:
            indicator = "○"
            color = TEXT_DIM

        tk.Label(row, text=indicator, bg=PANEL, fg=color,
                 font=("Consolas", 10)).pack(side="left", padx=(2, 4))

        var = tk.BooleanVar(value=False)
        self.check_vars[feat.name] = var

        # Auto-select root and mandatory features
        if feat.parent is None or feat.mandatory:
            var.set(True)

        cb_state = "disabled" if (feat.parent is None) else "normal"

        cb = ttk.Checkbutton(row, text=feat.name, variable=var,
                              state=cb_state,
                              command=lambda f=feat: self._on_check(f))
        cb.pack(side="left")
        self.check_widgets[feat.name] = cb

        # Tag label
        tags = []
        if feat.parent is None:
            tags.append("root")
        if feat.mandatory:
            tags.append("mandatory")
        if feat.group_type:
            tags.append(feat.group_type.upper())
        if tags:
            tk.Label(row, text=f"[{' | '.join(tags)}]",
                     bg=PANEL, fg=TEXT_DIM, font=("Consolas", 8)).pack(side="left", padx=4)

        # Children
        for child in feat.children:
            if child.group_type is None:
                self._render_feature(child, parent_widget, depth + 1, False)

        # Groups
        for group in (self.parser.groups if self.parser else []):
            if group["parent"] is feat:
                gtype = group["type"].upper()
                gframe = tk.Frame(parent_widget, bg=PANEL,
                                  highlightthickness=1,
                                  highlightbackground=YELLOW if gtype == "XOR" else ACCENT2)
                gframe.pack(fill="x", padx=(depth * 18 + 18, 4), pady=3)
                tk.Label(gframe, text=f" {gtype} GROUP ",
                         bg=YELLOW if gtype == "XOR" else ACCENT2,
                         fg=BG, font=("Consolas", 8, "bold")).pack(anchor="w")
                for m in group["members"]:
                    self._render_feature(m, gframe, 0, True)

    def _on_check(self, feat: Feature):
        if self._suppress_callbacks:
            return
        self._suppress_callbacks = True

        selected_name = feat.name
        is_now_selected = self.check_vars[feat.name].get()

        # XOR: deselect siblings
        if feat.group_type == "xor" and is_now_selected:
            for sibling in feat.group_members:
                self.check_vars[sibling.name].set(False)
                self._deselect_subtree(sibling)

        # Cross-tree: ByLocation → Location
        if is_now_selected:
            for c in self.parser.constraints:
                prop = c.propositional or ""
                import re
                m = re.match(r"(\w+)\s*→\s*(\w+)", prop)
                if m and m.group(1) == selected_name:
                    dep_name = m.group(2)
                    if dep_name in self.check_vars:
                        self.check_vars[dep_name].set(True)
                        # Also enable its group children if needed
                        self._auto_select_groups(self.parser.features[dep_name])

        # If deselecting a mandatory parent, warn
        if not is_now_selected and feat.mandatory:
            self.check_vars[feat.name].set(True)  # revert
            self._show_output(self.valid_text,
                              f"⚠  Cannot deselect mandatory feature: {feat.name}\n", RED)
            self._suppress_callbacks = False
            return

        # If deselecting parent, deselect children
        if not is_now_selected:
            self._deselect_subtree(feat)

        self._suppress_callbacks = False
        self._run_quick_check()

    def _deselect_subtree(self, feat: Feature):
        for child in feat.children:
            if child.name in self.check_vars:
                self.check_vars[child.name].set(False)
                self._deselect_subtree(child)
        for group in (self.parser.groups if self.parser else []):
            if group["parent"] is feat:
                for m in group["members"]:
                    self.check_vars[m.name].set(False)
                    self._deselect_subtree(m)

    def _auto_select_groups(self, feat: Feature):
        """If a parent is selected that has OR/XOR groups, don't auto-select — just enable."""
        pass

    def _run_quick_check(self):
        selected = {n for n, v in self.check_vars.items() if v.get()}
        valid, msg = self.validator.validate(selected)
        color = GREEN if valid else RED
        self._show_output(self.valid_text, msg + "\n", color)

    def _validate_selection(self):
        if not self.validator:
            messagebox.showwarning("No Model", "Please load an XML model first.")
            return
        selected = {n for n, v in self.check_vars.items() if v.get()}
        valid, msg = self.validator.validate(selected)
        color = GREEN if valid else RED

        detail = "\nSelected features:\n  " + ", ".join(sorted(selected))
        self._show_output(self.valid_text, msg + detail + "\n", color)

    def _generate_mwps(self):
        if not self.mwp_gen:
            messagebox.showwarning("No Model", "Please load an XML model first.")
            return
        self.status_var.set("Computing MWPs…")
        self._show_output(self.mwp_text, "⏳ Computing Minimum Working Products…\n", YELLOW)

        def run():
            mwps = self.mwp_gen.generate()
            self.after(0, lambda: self._display_mwps(mwps))

        threading.Thread(target=run, daemon=True).start()

    def _display_mwps(self, mwps):
        if not mwps:
            self._show_output(self.mwp_text, "No valid MWPs found.\n", RED)
            return
        lines = [f"Found {len(mwps)} Minimum Working Product(s):\n"]
        for i, mwp in enumerate(mwps, 1):
            features = sorted(mwp)
            lines.append(f"MWP #{i}  ({len(features)} features):")
            lines.append("  " + ",  ".join(features))
            lines.append("")
        self._show_output(self.mwp_text, "\n".join(lines), GREEN)
        self.status_var.set(f"MWP generation complete — {len(mwps)} product(s) found.")

    def _populate_logic(self):
        if not self.translator:
            return
        lines = ["Propositional Logic Rules:\n"]
        lines.append(self.translator.get_rules_text())
        lines.append("\n\nCNF Encoding (variable → feature name):")
        for name, var in self.translator.var_map.items():
            lines.append(f"  x{var}  =  {name}")
        self._show_output(self.logic_text, "\n".join(lines), TEXT)

    def _populate_constraints(self):
        if not self.parser:
            return
        if not self.parser.constraints:
            self._show_output(self.constraint_text, "No constraints found in model.\n", TEXT_DIM)
            return
        lines = []
        for i, c in enumerate(self.parser.constraints, 1):
            lines.append(f"Constraint {i}:")
            if c.english:
                lines.append(f"  English : {c.english}")
            if c.boolean_expr:
                lines.append(f"  Boolean : {c.boolean_expr}")
            if c.propositional:
                lines.append(f"  Logic   : {c.propositional}")
            lines.append("")
        self._show_output(self.constraint_text, "\n".join(lines), ACCENT)

    def _clear_all(self):
        self.parser = None
        self.translator = None
        self.validator = None
        self.mwp_gen = None
        for w in self.tree_inner.winfo_children():
            w.destroy()
        self.check_vars.clear()
        self.check_widgets.clear()
        for t in [self.logic_text, self.constraint_text, self.valid_text, self.mwp_text]:
            self._clear_output(t)
        self.status_var.set("Cleared.")

    # ──────────────────────────────────────────
    #  HELPERS
    # ──────────────────────────────────────────

    def _show_output(self, widget, text, color=TEXT):
        widget.config(state="normal")
        widget.delete("1.0", "end")
        widget.insert("end", text)
        widget.tag_add("color", "1.0", "end")
        widget.tag_config("color", foreground=color)
        widget.config(state="disabled")

    def _clear_output(self, widget):
        widget.config(state="normal")
        widget.delete("1.0", "end")
        widget.config(state="disabled")


# ──────────────────────────────────────────────
#  ENTRY POINT
# ──────────────────────────────────────────────

if __name__ == "__main__":
    app = FeatureModelApp()
    app.mainloop()
