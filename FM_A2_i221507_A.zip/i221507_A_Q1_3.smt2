(set-logic QF_UF)
(declare-const q Bool)
(declare-const r Bool)
(declare-const s Bool)
(declare-const t Bool)

(assert (and (=> q r) (=> r s) (=> s t) (=> t (not q)) q))
(check-sat)