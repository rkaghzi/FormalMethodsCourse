(set-logic QF_UF)
(declare-const p Bool)
(declare-const q Bool)
(declare-const r Bool)
(declare-const s Bool)

(assert (not (=> (or (and p q) (and r s)) (and (or p r) (or q s)))))
(check-sat)