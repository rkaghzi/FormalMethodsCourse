(set-logic QF_UF)
(declare-const p Bool)
(declare-const q Bool)
(declare-const r Bool)

(assert (not (=> (and (=> p q) (=> q r)) (=> p r))))
(check-sat)