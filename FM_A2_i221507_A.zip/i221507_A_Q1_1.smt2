(set-logic QF_UF)
(declare-const p Bool)
(declare-const q Bool)
(declare-const r Bool)
(declare-const s Bool)
(declare-const t Bool)

(assert (not (=> (and (not p) (=> q r)) (and (or (not s) t) (=> q p)))))
(check-sat)