(set-logic QF_LIA)
(declare-const C Int)
(declare-const M Int)
(declare-const S Int)
(declare-const B Int)

(assert (<= (+ (* 3 C) (* 4 M) (* 2 S)) 60))
(assert (= B (+ (* C C) 10)))
(assert (=> (> C 4) (and (< M 4) (>= S 10))))
(assert (= (- (* 2 M) S) 4))
(assert (>= (+ C S) 15))

(check-sat)
(get-model)