Feature Model Analysis Tool — FAST NUCES Formal Methods Project
================================================================
Version 2.0 | Fall 2026

QUICK START
-----------
1. Install dependency:
      pip install python-sat

2. Run:
      python app.py

FILES
-----
app.py         — Main GUI application (Tkinter)
fm_core.py     — Part 1 core: XML parser, logic translator, SAT validator, MWP generator
part2_core.py  — Part 2 core: codebase loader, dependency extractor, inconsistency detector
feature-model.xml  — Sample feature model XML
user_guide.pdf — Full user guide
sample_codebase/   — Sample Python codebase for Part 2 (18 files)

WHAT IS IMPLEMENTED
--------------------
PART 1:
  - XML parsing (file or paste)
  - Propositional logic translation with CNF encoding
  - PySAT Glucose3 SAT solver for validation
  - Cross-tree constraint support (English + auto-translate + confirm dialog)
  - Dynamic interactive feature tree (XOR auto-disable, mandatory protection)
  - Minimum Working Product (MWP) generation
  - Export logic rules to text file

PART 2:
  - Codebase loader (local folder)
  - Feature-to-file mapping (14 features mapped with justification)
  - Import-based dependency extraction with evidence (line numbers)
  - Feature-level dependency inference
  - Inconsistency detection (hidden, missing, incorrect)
  - Impact analysis (direct + transitive files)
  - Export full report to text file
