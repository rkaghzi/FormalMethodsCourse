"""
Complete test script — verifies ALL PDF requirements without running GUI.
Run:  python test_all.py
"""

import sys, traceback

PASS = "✅ PASS"
FAIL = "❌ FAIL"
results = []

def test(name, fn):
    try:
        fn()
        results.append((PASS, name))
        print(f"  {PASS}  {name}")
    except Exception as e:
        results.append((FAIL, name + f"  →  {e}"))
        print(f"  {FAIL}  {name}")
        traceback.print_exc()

print("=" * 65)
print("  FEATURE MODEL TOOL — FULL TEST SUITE")
print("=" * 65)

# ──────────────────────────────────────────────────────────────
print("\n📦  PART 1 — XML PARSING & LOGIC TRANSLATION\n")

from fm_core import FeatureModelParser, LogicTranslator, SATValidator, MWPGenerator, Constraint

def t_xml_load():
    p = FeatureModelParser().parse("feature-model.xml")
    assert p.root is not None, "Root missing"
    assert p.root.name == "Application"
test("XML file loading", t_xml_load)

def t_xml_paste():
    xml = open("feature-model.xml").read()
    p = FeatureModelParser().parse(xml)
    assert p.root is not None
test("XML paste/string parsing", t_xml_paste)

def t_mandatory():
    p = FeatureModelParser().parse("feature-model.xml")
    names = [f.name for f in p.root.children if f.mandatory]
    assert "Catalog" in names, f"Catalog should be mandatory, got {names}"
    assert "Payment" in names, f"Payment should be mandatory, got {names}"
test("Mandatory features parsed correctly", t_mandatory)

def t_optional():
    p = FeatureModelParser().parse("feature-model.xml")
    names = [f.name for f in p.root.children if not f.mandatory]
    assert "Notification" in names
    assert "Location" in names
test("Optional features parsed correctly", t_optional)

def t_xor_group():
    p = FeatureModelParser().parse("feature-model.xml")
    xor_groups = [g for g in p.groups if g["type"] == "xor"]
    assert len(xor_groups) >= 2, f"Expected >=2 XOR groups, got {len(xor_groups)}"
    members_flat = [m.name for g in xor_groups for m in g["members"]]
    assert "SMS" in members_flat and "Call" in members_flat
test("XOR groups parsed (Notification, Filtered)", t_xor_group)

def t_or_group():
    p = FeatureModelParser().parse("feature-model.xml")
    or_groups = [g for g in p.groups if g["type"] == "or"]
    assert len(or_groups) >= 1, "No OR groups found"
    members_flat = [m.name for g in or_groups for m in g["members"]]
    assert "WiFi" in members_flat or "GPS" in members_flat
test("OR groups parsed (Location, Payment)", t_or_group)

def t_cross_tree():
    p = FeatureModelParser().parse("feature-model.xml")
    assert len(p.constraints) >= 1, "No constraints found"
    props = [c.propositional for c in p.constraints if c.propositional]
    assert any("ByLocation" in pr for pr in props), "ByLocation→Location constraint missing"
test("Cross-tree constraint parsed from XML", t_cross_tree)

# ──────────────────────────────────────────────────────────────
print("\n📐  PART 1 — PROPOSITIONAL LOGIC TRANSLATION\n")

def t_root_rule():
    p = FeatureModelParser().parse("feature-model.xml")
    t = LogicTranslator(p)
    rules = t.get_rules_text()
    assert "Root: Application" in rules
    assert "always True" in rules
test("Root rule:  Application  (always True)", t_root_rule)

def t_mandatory_rule():
    p = FeatureModelParser().parse("feature-model.xml")
    t = LogicTranslator(p)
    rules = t.get_rules_text()
    assert "Application → Catalog" in rules
    assert "Application → Payment" in rules
test("Mandatory rule:  Parent → Child", t_mandatory_rule)

def t_optional_rule():
    p = FeatureModelParser().parse("feature-model.xml")
    t = LogicTranslator(p)
    rules = t.get_rules_text()
    assert "↔" in rules, "Optional rule must use ↔"
    assert "Notification ∨ ¬Notification" in rules
test("Optional rule:  B ↔ (A ∨ ¬A)", t_optional_rule)

def t_xor_formula():
    p = FeatureModelParser().parse("feature-model.xml")
    t = LogicTranslator(p)
    rules = t.get_rules_text()
    assert "SMS ∧ ¬Call" in rules or "¬SMS ∧ Call" in rules, \
        "XOR formula (A ∧ ¬B) ∨ (B ∧ ¬A) not found"
test("XOR formula:  (A ∧ ¬B) ∨ (B ∧ ¬A)", t_xor_formula)

def t_or_formula():
    p = FeatureModelParser().parse("feature-model.xml")
    t = LogicTranslator(p)
    rules = t.get_rules_text()
    assert "WiFi ∨ GPS" in rules or "CreditCard ∨ Discount" in rules
test("OR formula:  (A ∨ B)", t_or_formula)

def t_crosstree_rule():
    p = FeatureModelParser().parse("feature-model.xml")
    t = LogicTranslator(p)
    rules = t.get_rules_text()
    assert "ByLocation → Location" in rules
test("Cross-tree rule:  ByLocation → Location", t_crosstree_rule)

# ──────────────────────────────────────────────────────────────
print("\n🔬  PART 1 — SAT VERIFICATION\n")

def t_valid_config():
    p = FeatureModelParser().parse("feature-model.xml")
    t = LogicTranslator(p)
    v = SATValidator(t)
    ok, msg = v.validate({"Application","Catalog","Filtered","Payment","CreditCard","ByDiscount"})
    assert ok, f"Expected VALID, got: {msg}"
test("Valid config accepted  ✔", t_valid_config)

def t_missing_mandatory():
    p = FeatureModelParser().parse("feature-model.xml")
    v = SATValidator(LogicTranslator(p))
    ok, msg = v.validate({"Application","Catalog"})   # missing Filtered, Payment
    assert not ok, "Should be INVALID (mandatory features missing)"
    assert "Filtered" in msg or "Payment" in msg
test("Invalid: missing mandatory features rejected  ✔", t_missing_mandatory)

def t_xor_violation():
    p = FeatureModelParser().parse("feature-model.xml")
    v = SATValidator(LogicTranslator(p))
    ok, msg = v.validate({"Application","Catalog","Filtered","Payment","CreditCard",
                           "ByDiscount","ByWeather"})   # two XOR members selected
    assert not ok, "Should be INVALID (XOR violation)"
test("Invalid: XOR violation rejected  ✔", t_xor_violation)

def t_crosstree_violation():
    p = FeatureModelParser().parse("feature-model.xml")
    v = SATValidator(LogicTranslator(p))
    ok, msg = v.validate({"Application","Catalog","Filtered","Payment","CreditCard","ByLocation"})
    assert not ok, "Should be INVALID (ByLocation without Location)"
    assert "constraint" in msg.lower() or "ByLocation" in msg
test("Invalid: cross-tree violation (ByLocation without Location)  ✔", t_crosstree_violation)

def t_detailed_reason():
    p = FeatureModelParser().parse("feature-model.xml")
    v = SATValidator(LogicTranslator(p))
    ok, msg = v.validate({"Application","Catalog"})
    assert len(msg) > 20, "Reason must be detailed, not just True/False"
test("Detailed failure reason shown  ✔", t_detailed_reason)

# ──────────────────────────────────────────────────────────────
print("\n🧩  PART 1 — MINIMUM WORKING PRODUCTS\n")

def t_mwp_count():
    p = FeatureModelParser().parse("feature-model.xml")
    v = SATValidator(LogicTranslator(p))
    g = MWPGenerator(p, v)
    mwps = g.generate()
    assert len(mwps) >= 4, f"Expected >=4 MWPs, got {len(mwps)}"
test(f"MWPs generated (count >= 4)", t_mwp_count)

def t_mwp_all_valid():
    p = FeatureModelParser().parse("feature-model.xml")
    t2 = LogicTranslator(p)
    v = SATValidator(t2)
    mwps = MWPGenerator(p, v).generate()
    for m in mwps:
        ok, msg = v.validate(m)
        assert ok, f"MWP {sorted(m)} is INVALID: {msg}"
test("All MWPs are valid configurations  ✔", t_mwp_all_valid)

def t_mwp_mandatory_included():
    p = FeatureModelParser().parse("feature-model.xml")
    v = SATValidator(LogicTranslator(p))
    mwps = MWPGenerator(p, v).generate()
    for m in mwps:
        assert "Application" in m and "Catalog" in m and "Payment" in m, \
            f"Mandatory features missing in MWP: {sorted(m)}"
test("All MWPs include mandatory features  ✔", t_mwp_mandatory_included)

def t_mwp_crosstree_respected():
    p = FeatureModelParser().parse("feature-model.xml")
    v = SATValidator(LogicTranslator(p))
    mwps = MWPGenerator(p, v).generate()
    for m in mwps:
        if "ByLocation" in m:
            assert "Location" in m, f"ByLocation in MWP but Location missing: {sorted(m)}"
test("MWPs respect cross-tree constraint (ByLocation → Location)  ✔", t_mwp_crosstree_respected)

# ──────────────────────────────────────────────────────────────
print("\n✏️   PART 1 — ENGLISH → LOGIC TRANSLATION\n")

import re

def translate(eng):
    el = eng.lower()
    m = re.search(r"the\s+(\w+)\s+feature\s+is\s+required\s+to\s+filter\s+the\s+catalog\s+by\s+(\w+)", el)
    if m: return f"By{m.group(2).capitalize()} → {m.group(1).capitalize()}"
    m = re.search(r"(?:[Ff]eature\s+)?(\w+)\s+requires\s+(?:[Ff]eature\s+)?(\w+)", eng, re.IGNORECASE)
    if m: return f"{m.group(1)} → {m.group(2)}"
    m = re.search(r"(?:[Ff]eature\s+)?(\w+)\s+excludes\s+(?:[Ff]eature\s+)?(\w+)", eng, re.IGNORECASE)
    if m: return f"¬({m.group(1)} ∧ {m.group(2)})"
    m = re.search(r"(\w+)\s+implies\s+(\w+)", eng, re.IGNORECASE)
    if m: return f"{m.group(1)} → {m.group(2)}"
    return None

def t_eng_requires():
    r = translate("Feature A requires Feature B")
    assert r == "A → B", f"Got: {r}"
test("English 'Feature A requires Feature B'  →  A → B", t_eng_requires)

def t_eng_excludes():
    r = translate("SMS excludes Call")
    assert r == "¬(SMS ∧ Call)", f"Got: {r}"
test("English 'SMS excludes Call'  →  ¬(SMS ∧ Call)", t_eng_excludes)

def t_eng_location():
    r = translate("The location feature is required to filter the catalog by location.")
    assert r == "ByLocation → Location", f"Got: {r}"
test("English 'location required to filter by location'  →  ByLocation → Location", t_eng_location)

def t_add_constraint_runtime():
    p = FeatureModelParser().parse("feature-model.xml")
    c = Constraint(); c.english = "SMS excludes Call"; c.propositional = "¬(SMS ∧ Call)"
    p.constraints.append(c)
    t2 = LogicTranslator(p)
    v  = SATValidator(t2)
    # Both SMS and Call selected → should be invalid
    ok, msg = v.validate({"Application","Catalog","Filtered","Payment","CreditCard",
                           "ByDiscount","Notification","SMS","Call"})
    assert not ok, "Added constraint should make SMS+Call invalid"
test("Runtime constraint add → SAT rebuilds & blocks SMS+Call  ✔", t_add_constraint_runtime)

# ──────────────────────────────────────────────────────────────
print("\n💻  PART 2 — CODE IMPACT ANALYSIS\n")

from part2_core import (CodebaseLoader, DependencyExtractor, FeatureDependencyDeriver,
                        InconsistencyDetector, ImpactAnalyser, FEATURE_FILE_MAPPING,
                        MAPPING_JUSTIFICATIONS)

def t_files_loaded():
    l = CodebaseLoader(); l.load_folder("sample_codebase")
    n = len(l.files)
    assert 10 <= n <= 25, f"Files must be 10-25, got {n}"
test(f"Codebase: 10–25 files loaded  ✔", t_files_loaded)

def t_min_mappings():
    assert len(FEATURE_FILE_MAPPING) >= 5
    for feat, files in FEATURE_FILE_MAPPING.items():
        assert len(files) >= 1, f"{feat} has no files"
test(f"Feature-to-file mapping: ≥5 features, each has ≥1 file  ✔", t_min_mappings)

def t_mapping_justified():
    assert len(MAPPING_JUSTIFICATIONS) >= 5
    for feat in FEATURE_FILE_MAPPING:
        just = MAPPING_JUSTIFICATIONS.get(feat,"")
        assert len(just) > 10, f"Justification too short for {feat}: '{just}'"
test("All mappings have justifications  ✔", t_mapping_justified)

def t_file_deps():
    l = CodebaseLoader(); l.load_folder("sample_codebase")
    deps = DependencyExtractor(l).extract()
    assert len(deps) >= 5, f"Need ≥5 deps, got {len(deps)}"
    for d in deps:
        assert d.evidence, f"Dep {d.source}→{d.target} has no evidence"
        assert d.line_number > 0
test(f"File deps: ≥5 extracted with line-number evidence  ✔", t_file_deps)

def t_feature_deps():
    l = CodebaseLoader(); l.load_folder("sample_codebase")
    deps = DependencyExtractor(l).extract()
    fdeps = FeatureDependencyDeriver(deps).derive()
    assert len(fdeps) >= 5, f"Need ≥5 feature deps, got {len(fdeps)}"
test("Feature-level deps inferred from file deps  ✔", t_feature_deps)

def t_inconsistencies():
    p = FeatureModelParser().parse("feature-model.xml")
    l = CodebaseLoader(); l.load_folder("sample_codebase")
    deps = DependencyExtractor(l).extract()
    fdeps = FeatureDependencyDeriver(deps).derive()
    incons = InconsistencyDetector(fdeps, p).detect()
    assert len(incons) >= 1, "Must detect ≥1 inconsistency"
    kinds = {i.kind for i in incons}
    assert len(kinds) >= 1
    for inc in incons:
        assert inc.evidence, f"Inconsistency {inc.source_feature}→{inc.target_feature} has no evidence"
        assert inc.resolution, "Must have resolution text"
test("Inconsistencies: ≥1 detected with evidence + resolution  ✔", t_inconsistencies)

def t_inconsistency_kinds():
    p = FeatureModelParser().parse("feature-model.xml")
    l = CodebaseLoader(); l.load_folder("sample_codebase")
    deps = DependencyExtractor(l).extract()
    fdeps = FeatureDependencyDeriver(deps).derive()
    incons = InconsistencyDetector(fdeps, p).detect()
    kinds = {i.kind for i in incons}
    valid_kinds = {"hidden","missing","incorrect"}
    assert kinds.issubset(valid_kinds), f"Invalid kinds: {kinds - valid_kinds}"
    assert len(kinds) >= 2, f"Should cover ≥2 categories, got: {kinds}"
test("Inconsistencies classified: hidden / missing / incorrect  ✔", t_inconsistency_kinds)

def t_impact_analysis():
    l = CodebaseLoader(); l.load_folder("sample_codebase")
    deps = DependencyExtractor(l).extract()
    sel = {"Catalog","Filtered","ByDiscount","Payment","CreditCard"}
    res = ImpactAnalyser(deps).analyse(sel)
    assert len(res["direct_files"]) >= 1, "No direct files found"
    assert len(res["all_impacted"]) >= 1
test("Impact analysis: direct + indirect files shown  ✔", t_impact_analysis)

def t_impact_transitive():
    l = CodebaseLoader(); l.load_folder("sample_codebase")
    deps = DependencyExtractor(l).extract()
    sel = {"Payment","CreditCard"}
    res = ImpactAnalyser(deps).analyse(sel)
    # Payment deps on auth via checkout
    assert len(res["indirect_files"]) >= 1, \
        f"Expected transitive deps, got none. direct={res['direct_files']}"
test("Impact analysis: transitive (indirect) deps found  ✔", t_impact_transitive)

# ──────────────────────────────────────────────────────────────
print("\n" + "=" * 65)
total   = len(results)
passed  = sum(1 for r in results if r[0] == PASS)
failed  = total - passed

print(f"\n  RESULTS:  {passed} / {total} PASSED")
if failed:
    print(f"\n  FAILED TESTS:")
    for r in results:
        if r[0] == FAIL:
            print(f"    {r[0]}  {r[1]}")
else:
    print(f"\n  🎉  ALL {total} TESTS PASSED — Tool is complete per PDF requirements!")
print("=" * 65)
