# auth/auth.py
# Authentication and session management

import shared.config as config
import shared.database as database

_sessions = {}

def login(username, password):
    """Authenticate user and return session token."""
    user = database.get("users", username)
    if user and user.get("password") == password:
        token = f"tok_{username}_001"
        _sessions[token] = username
        return token
    return None

def logout(token):
    _sessions.pop(token, None)

def get_user(token):
    return _sessions.get(token)

def is_authenticated(token):
    return token in _sessions

def require_auth(token):
    if not is_authenticated(token):
        raise PermissionError("Authentication required.")
    return get_user(token)
