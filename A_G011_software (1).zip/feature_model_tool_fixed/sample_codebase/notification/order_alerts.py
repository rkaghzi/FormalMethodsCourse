# notification/order_alerts.py
# Order-related notifications sent after checkout

import notification.notification as notification
import shared.database as database

def notify_order_confirmed(user_id, order_total):
    msg = f"Your order of PKR {order_total:.0f} has been confirmed. Thank you!"
    return notification.notify_user(user_id, msg, method="sms")

def notify_order_shipped(user_id, tracking_id):
    msg = f"Your order is on the way! Tracking ID: {tracking_id}"
    return notification.notify_user(user_id, msg, method="sms")

def notify_payment_failed(user_id, reason):
    msg = f"Payment failed: {reason}. Please try again."
    return notification.notify_user(user_id, msg, method="call")
