# location/location.py
# Location feature: WiFi triangulation and GPS support

import shared.config as config
import shared.database as database

def get_location_by_wifi():
    """Estimate user location via WiFi access point scanning."""
    # In real app: scan nearby APs and query location DB
    return {"lat": 33.6844, "lon": 73.0479, "method": "WiFi", "accuracy": "medium"}

def get_location_by_gps():
    """Get precise location via GPS hardware."""
    # In real app: read from GPS sensor
    return {"lat": 33.6844, "lon": 73.0479, "method": "GPS", "accuracy": "high"}

def get_best_location():
    """Return best available location."""
    if config.FEATURE_LOCATION:
        return get_location_by_gps()
    return None

def save_user_location(user_id, location):
    database.put("locations", user_id, location)

def get_user_location(user_id):
    return database.get("locations", user_id)
