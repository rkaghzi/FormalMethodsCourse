# shared/logger.py
# Simple logging utility

import shared.config as config
from datetime import datetime

def log(level, module, message):
    if config.DEBUG or level in ("ERROR", "WARN"):
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] [{level}] [{module}] {message}")

def info(module, msg):  log("INFO",  module, msg)
def warn(module, msg):  log("WARN",  module, msg)
def error(module, msg): log("ERROR", module, msg)
