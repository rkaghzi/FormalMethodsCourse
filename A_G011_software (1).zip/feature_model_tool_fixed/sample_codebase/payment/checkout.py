# payment/checkout.py
# Shopping cart and checkout flow

import payment.payment as payment
import catalog.catalog as catalog
import auth.auth as auth
import shared.database as database

def add_to_cart(token, product_id, quantity=1):
    user = auth.require_auth(token)
    product = catalog.get_product(product_id)
    if not product:
        raise ValueError(f"Product {product_id} not found.")
    cart = database.get("carts", user) or {}
    cart[product_id] = cart.get(product_id, 0) + quantity
    database.put("carts", user, cart)
    return cart

def get_cart(token):
    user = auth.require_auth(token)
    return database.get("carts", user) or {}

def checkout(token, card_number, discount_code=None):
    """Complete checkout: apply discount if any, then charge card."""
    user = auth.require_auth(token)
    cart = get_cart(token)
    if not cart:
        raise ValueError("Cart is empty.")

    # Calculate total
    total = 0
    for pid, qty in cart.items():
        product = catalog.get_product(pid)
        if product:
            total += product["price"] * qty

    # Apply discount
    if discount_code:
        result = payment.apply_discount(token, total, discount_code)
        total = result["total"]

    # Charge
    result = payment.charge_credit_card(token, total, card_number)

    # Clear cart
    database.delete("carts", user)
    return {"order_total": total, "payment": result}
