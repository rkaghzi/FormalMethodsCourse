"""
Feature Model Analysis Tool — Part 1
FAST NUCES — Formal Methods Project
"""

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Optional
import re


# ─────────────────────────────────────────────
#  DATA STRUCTURES
# ─────────────────────────────────────────────

@dataclass
class Feature:
    name: str
    mandatory: bool = False
    parent: Optional["Feature"] = None
    children: list = field(default_factory=list)
    group_type: Optional[str] = None   # 'xor' | 'or' | None
    group_members: list = field(default_factory=list)  # siblings in same group

    def __repr__(self):
        return f"Feature({self.name}, mandatory={self.mandatory})"


@dataclass
class Constraint:
    english: Optional[str] = None
    boolean_expr: Optional[str] = None
    propositional: Optional[str] = None   # derived


# ─────────────────────────────────────────────
#  XML PARSER
# ─────────────────────────────────────────────

class FeatureModelParser:
    def __init__(self):
        self.features: dict[str, Feature] = {}
        self.root: Optional[Feature] = None
        self.constraints: list[Constraint] = []
        self.groups: list[dict] = []   # {type, members}

    def parse(self, xml_source: str) -> "FeatureModelParser":
        """Parse XML string or file path."""
        try:
            if xml_source.strip().startswith("<"):
                root_elem = ET.fromstring(xml_source)
            else:
                tree = ET.parse(xml_source)
                root_elem = tree.getroot()
        except ET.ParseError as e:
            raise ValueError(f"XML Parse Error: {e}")

        # Root <featureModel>
        feature_elems = root_elem.findall("feature")
        if not feature_elems:
            raise ValueError("No root feature found in XML.")

        self.root = self._parse_feature(feature_elems[0], parent=None, parent_mandatory=True)

        # Constraints
        constraints_elem = root_elem.find("constraints")
        if constraints_elem is not None:
            for c_elem in constraints_elem.findall("constraint"):
                c = Constraint()
                eng = c_elem.find("englishStatement")
                bool_e = c_elem.find("booleanExpression")
                if eng is not None and eng.text:
                    c.english = eng.text.strip()
                    c.propositional = self._translate_english_constraint(c.english)
                if bool_e is not None and bool_e.text:
                    c.boolean_expr = bool_e.text.strip()
                    c.propositional = self._parse_boolean_expr(c.boolean_expr)
                self.constraints.append(c)

        return self

    def _parse_feature(self, elem, parent: Optional[Feature], parent_mandatory: bool) -> Feature:
        name = elem.get("name", "Unknown")
        mandatory_attr = elem.get("mandatory", None)

        # Determine mandatory: if attr absent AND parent is root call, default False for optional
        # Root feature is always mandatory
        if parent is None:
            mandatory = True
        elif mandatory_attr is not None:
            mandatory = mandatory_attr.lower() == "true"
        else:
            mandatory = False  # absence means optional

        feat = Feature(name=name, mandatory=mandatory, parent=parent)
        self.features[name] = feat

        if parent is not None:
            parent.children.append(feat)

        # Parse children
        for child_elem in elem.findall("feature"):
            self._parse_feature(child_elem, parent=feat, parent_mandatory=mandatory)

        # Parse groups
        for group_elem in elem.findall("group"):
            group_type = group_elem.get("type", "or").lower()
            members = []
            for gf_elem in group_elem.findall("feature"):
                gf = self._parse_feature(gf_elem, parent=feat, parent_mandatory=False)
                gf.group_type = group_type
                members.append(gf)
            # Link siblings
            for m in members:
                m.group_members = [x for x in members if x is not m]
            self.groups.append({"type": group_type, "members": members, "parent": feat})

        return feat

    def _translate_english_constraint(self, english: str) -> str:
        """Heuristic NL → propositional logic for 'requires' constraints."""
        english_lower = english.lower()
        # Pattern: "X requires Y" / "X is required to/for Y" / "Y required by X"
        req_pattern = re.compile(
            r"(?:the\s+)?(\w+)\s+feature\s+is\s+required\s+to\s+filter\s+the\s+catalog\s+by\s+(\w+)",
            re.IGNORECASE
        )
        m = req_pattern.match(english.strip())
        if m:
            # "Location feature is required to filter the catalog by location"
            # → ByLocation → Location
            dep_feature = m.group(1)   # Location
            filter_name = "By" + m.group(2).capitalize()  # ByLocation
            return f"{filter_name} → {dep_feature}"

        # Generic: "A requires B"
        m2 = re.search(r"(\w+)\s+requires\s+(\w+)", english, re.IGNORECASE)
        if m2:
            return f"{m2.group(1)} → {m2.group(2)}"

        # Generic: "A excludes B"
        m3 = re.search(r"(\w+)\s+excludes\s+(\w+)", english, re.IGNORECASE)
        if m3:
            return f"¬({m3.group(1)} ∧ {m3.group(2)})"

        return f"[Manual translation needed] {english}"

    def _parse_boolean_expr(self, expr: str) -> str:
        """Convert 'A implies B' style to → notation."""
        expr = re.sub(r"\bimplies\b", "→", expr, flags=re.IGNORECASE)
        expr = re.sub(r"\band\b", "∧", expr, flags=re.IGNORECASE)
        expr = re.sub(r"\bor\b", "∨", expr, flags=re.IGNORECASE)
        expr = re.sub(r"\bnot\b", "¬", expr, flags=re.IGNORECASE)
        return expr


# ─────────────────────────────────────────────
#  LOGIC TRANSLATOR
# ─────────────────────────────────────────────

class LogicTranslator:
    def __init__(self, parser: FeatureModelParser):
        self.parser = parser
        self.rules: list[str] = []
        self.cnf_clauses: list[list[int]] = []
        self.var_map: dict[str, int] = {}
        self._generate()

    def _var(self, name: str) -> int:
        if name not in self.var_map:
            self.var_map[name] = len(self.var_map) + 1
        return self.var_map[name]

    def _generate(self):
        self._process_feature(self.parser.root, is_root=True)
        self._process_constraints()

    def _process_feature(self, feat: Feature, is_root=False):
        if is_root:
            self.rules.append(f"Root: {feat.name}  (root feature — always True)")
            self.cnf_clauses.append([self._var(feat.name)])

        for child in feat.children:
            if child.group_type is not None:
                continue  # handled by group logic
            if child.mandatory:
                self.rules.append(f"Mandatory: {feat.name} → {child.name}")
                # parent → child AND child → parent (iff)
                pv, cv = self._var(feat.name), self._var(child.name)
                self.cnf_clauses.append([-pv, cv])   # parent → child
                self.cnf_clauses.append([-cv, pv])   # child → parent
            else:
                self.rules.append(f"Optional: {feat.name} ↔ ({child.name} ∨ ¬{child.name})")
                cv, pv = self._var(child.name), self._var(feat.name)
                self.cnf_clauses.append([-cv, pv])   # if child selected, parent must be
            self._process_feature(child)

        for group in self.parser.groups:
            if group["parent"] is not feat:
                continue
            gtype = group["type"]
            members = group["members"]
            mnames = [m.name for m in members]
            pv = self._var(feat.name)

            if gtype == "xor":
                xor_terms = []
                for chosen in mnames:
                    parts = [nm if nm == chosen else f"¬{nm}" for nm in mnames]
                    xor_terms.append("(" + " ∧ ".join(parts) + ")")
                xor_formula = " ∨ ".join(xor_terms)
                self.rules.append(f"XOR Group under {feat.name}: {xor_formula}")
                # Parent selected → at least one member selected
                clause = [-pv] + [self._var(n) for n in mnames]
                self.cnf_clauses.append(clause)
                # At most one: pairwise ¬A ∨ ¬B
                for i, a in enumerate(mnames):
                    for b in mnames[i+1:]:
                        self.cnf_clauses.append([-self._var(a), -self._var(b)])
                # If any member selected → parent selected
                for n in mnames:
                    self.cnf_clauses.append([-self._var(n), pv])

            elif gtype == "or":
                or_formula = " ∨ ".join(mnames)
                self.rules.append(f"OR Group under {feat.name}: ({or_formula})")
                clause = [-pv] + [self._var(n) for n in mnames]
                self.cnf_clauses.append(clause)
                for n in mnames:
                    self.cnf_clauses.append([-self._var(n), pv])

            for m in members:
                self._process_feature(m)

    def _process_constraints(self):
        for c in self.parser.constraints:
            prop = c.propositional or ""
            # Parse "A → B"
            m = re.match(r"(\w+)\s*→\s*(\w+)", prop)
            if m:
                a, b = m.group(1), m.group(2)
                self.rules.append(f"Cross-tree: {a} → {b}")
                self.cnf_clauses.append([-self._var(a), self._var(b)])
            # Parse "¬(A ∧ B)"
            m2 = re.match(r"¬\((\w+)\s*∧\s*(\w+)\)", prop)
            if m2:
                a, b = m2.group(1), m2.group(2)
                self.rules.append(f"Cross-tree (excludes): ¬({a} ∧ {b})")
                self.cnf_clauses.append([-self._var(a), -self._var(b)])

    def get_rules_text(self) -> str:
        return "\n".join(f"  {i+1}. {r}" for i, r in enumerate(self.rules))


# ─────────────────────────────────────────────
#  SAT VALIDATOR
# ─────────────────────────────────────────────

class SATValidator:
    def __init__(self, translator: LogicTranslator):
        self.translator = translator
        try:
            from pysat.solvers import Glucose3
            # Quick smoke test
            _s = Glucose3()
            _s.add_clause([1])
            _s.solve()
            _s.delete()
            self.Glucose3 = Glucose3
            self.available = True
        except Exception:
            self.available = False

    def validate(self, selected: set[str]) -> tuple[bool, str]:
        """Validate a feature selection. Returns (is_valid, reason)."""
        if not self.available:
            return self._manual_validate(selected)

        from pysat.solvers import Glucose3
        var_map = self.translator.var_map

        solver = Glucose3()
        for clause in self.translator.cnf_clauses:
            solver.add_clause(clause)

        # Fix selected features as True, unselected as False
        assumptions = []
        for name, var in var_map.items():
            if name in selected:
                assumptions.append(var)
            else:
                assumptions.append(-var)

        result = solver.solve(assumptions=assumptions)
        solver.delete()

        if result:
            return True, "✅ Valid configuration!"
        else:
            violation = self._find_violation(selected)
            return False, violation if violation else "❌ Invalid configuration (SAT solver detected conflict)"

    def _find_violation(self, selected: set[str]) -> str:
        reasons = []
        parser = self.translator.parser

        # Check mandatory features
        for name, feat in parser.features.items():
            if feat.mandatory and feat.parent and feat.parent.name in selected:
                if name not in selected:
                    reasons.append(f"Mandatory feature '{name}' must be selected (parent '{feat.parent.name}' is selected)")

        # Check root
        if parser.root and parser.root.name not in selected:
            reasons.append(f"Root feature '{parser.root.name}' must always be selected")

        # Check XOR
        for group in parser.groups:
            if group["type"] == "xor":
                parent_name = group["parent"].name
                if parent_name in selected:
                    sel_members = [m.name for m in group["members"] if m.name in selected]
                    if len(sel_members) == 0:
                        reasons.append(f"XOR group under '{parent_name}': at least one must be selected")
                    elif len(sel_members) > 1:
                        reasons.append(f"XOR group under '{parent_name}': only one allowed, got {sel_members}")

        # Check OR
        for group in parser.groups:
            if group["type"] == "or":
                parent_name = group["parent"].name
                if parent_name in selected:
                    sel_members = [m.name for m in group["members"] if m.name in selected]
                    if len(sel_members) == 0:
                        reasons.append(f"OR group under '{parent_name}': at least one must be selected")

        # Check cross-tree constraints
        for c in parser.constraints:
            prop = c.propositional or ""
            m = re.match(r"(\w+)\s*→\s*(\w+)", prop)
            if m:
                a, b = m.group(1), m.group(2)
                if a in selected and b not in selected:
                    reasons.append(f"Cross-tree constraint violated: '{a}' requires '{b}'")

        if reasons:
            return "❌ Invalid:\n" + "\n".join(f"  • {r}" for r in reasons)
        return ""   # empty string means no violations found

    def _manual_validate(self, selected: set[str]) -> tuple[bool, str]:
        """Fallback validation without PySAT."""
        reason = self._find_violation(selected)
        if reason:   # non-empty means violations were found
            return False, reason
        return True, "✅ Valid configuration!"


# ─────────────────────────────────────────────
#  MWP GENERATOR
# ─────────────────────────────────────────────

class MWPGenerator:
    def __init__(self, parser: FeatureModelParser, validator: SATValidator):
        self.parser = parser
        self.validator = validator
        self.mwps: list[set] = []

    def generate(self) -> list[set]:
        """Generate all Minimum Working Products by enumerating group choices."""
        self.mwps = []
        base = self._mandatory_set()
        # Generate all possible minimal configurations by varying XOR/OR choices
        from itertools import product as iterproduct

        # Collect all groups whose parent is in the mandatory set
        relevant_groups = [g for g in self.parser.groups if g["parent"].name in base]

        # For each group, possible minimal member choices
        group_options = []
        for group in relevant_groups:
            gtype = group["type"]
            members = group["members"]
            if gtype == "xor":
                # Each member is a separate choice
                group_options.append([{m.name} for m in members])
            elif gtype == "or":
                # Minimal: one member at a time
                group_options.append([{m.name} for m in members])

        if not group_options:
            # Just try the base
            all_combos = [set()]
        else:
            all_combos = [set().union(*combo) for combo in iterproduct(*group_options)]

        # Also try with optional parents (Notification, Location)
        optional_parents = [
            name for name, feat in self.parser.features.items()
            if not feat.mandatory and feat.group_type is None
               and any(g["parent"].name == name for g in self.parser.groups)
        ]

        extended_combos = list(all_combos)
        for opt in optional_parents:
            opt_groups = [g for g in self.parser.groups if g["parent"].name == opt]
            for g in opt_groups:
                for m in g["members"]:
                    for base_combo in all_combos:
                        extended_combos.append(base_combo | {opt, m.name})

        for choices in extended_combos:
            candidate = base | choices
            candidate = self._close_constraints(candidate)
            candidate = self._close_groups(candidate)
            valid, _ = self.validator.validate(candidate)
            if valid:
                self._add_mwp(candidate)

        return self.mwps

    def _add_mwp(self, candidate: set):
        fs = frozenset(candidate)
        existing_fs = [frozenset(m) for m in self.mwps]
        # Skip if superset of existing
        if any(e <= fs and e != fs for e in existing_fs):
            return
        # Remove existing supersets
        self.mwps = [m for m in self.mwps if not (fs < frozenset(m))]
        if fs not in [frozenset(m) for m in self.mwps]:
            self.mwps.append(set(candidate))

    def _mandatory_set(self) -> set:
        """Collect all features that MUST be in every valid configuration."""
        result = set()
        self._collect_mandatory(self.parser.root, result, parent_selected=True)
        return result

    def _collect_mandatory(self, feat: Feature, result: set, parent_selected: bool):
        if not parent_selected:
            return
        if feat.mandatory or feat.parent is None:
            result.add(feat.name)
            for child in feat.children:
                self._collect_mandatory(child, result, True)
            for group in self.parser.groups:
                if group["parent"] is feat:
                    for m in group["members"]:
                        self._collect_mandatory(m, result, False)

    def _in_mandatory_group(self, feat: Feature) -> bool:
        for group in self.parser.groups:
            if feat in group["members"]:
                parent = group["parent"]
                return parent.mandatory or parent.parent is None
        return False

    def _close_constraints(self, selected: set) -> set:
        """Apply cross-tree constraints (A → B: if A selected, add B)."""
        changed = True
        result = set(selected)
        while changed:
            changed = False
            for c in self.parser.constraints:
                prop = c.propositional or ""
                m = re.match(r"(\w+)\s*→\s*(\w+)", prop)
                if m:
                    a, b = m.group(1), m.group(2)
                    if a in result and b not in result:
                        result.add(b)
                        changed = True
        return result

    def _close_groups(self, selected: set) -> set:
        """For each selected parent with a group, add one valid member if none selected."""
        result = set(selected)
        changed = True
        while changed:
            changed = False
            for group in self.parser.groups:
                parent_name = group["parent"].name
                if parent_name not in result:
                    continue
                members = group["members"]
                sel = [m for m in members if m.name in result]
                if not sel:
                    # Add first (minimal) member
                    result.add(members[0].name)
                    changed = True
                    # If OR group under Location we also need WiFi or GPS
        return result
