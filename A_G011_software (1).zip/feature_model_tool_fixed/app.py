"""
Feature Model Analysis Tool — GUI (Tkinter)
FAST NUCES — Formal Methods Project
Part 1: Feature Model Analysis
Part 2: Feature-to-Code Impact Analysis
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from fm_core import FeatureModelParser, LogicTranslator, SATValidator, MWPGenerator, Feature, Constraint
from typing import Optional
import threading, os, re

BG        = "#0f1117"
PANEL     = "#1a1d27"
BORDER    = "#2a2d3a"
ACCENT    = "#6c8fff"
ACCENT2   = "#a78bfa"
GREEN     = "#4ade80"
RED       = "#f87171"
YELLOW    = "#fbbf24"
TEXT      = "#e2e8f0"
TEXT_DIM  = "#64748b"
FONT_MAIN = ("Consolas", 10)


class ConstraintDialog(tk.Toplevel):
    """Dialog for adding cross-tree constraints with English -> Logic translation."""
    def __init__(self, parent, existing_constraints=None):
        super().__init__(parent)
        self.title("Add Cross-Tree Constraint")
        self.configure(bg=BG)
        self.geometry("720x560")
        self.transient(parent)
        self.grab_set()
        self.result = None
        self._build(existing_constraints or [])

    def _build(self, existing):
        tk.Label(self, text="  Cross-Tree Constraint Editor", bg=PANEL, fg=ACCENT,
                 font=("Consolas", 13, "bold")).pack(fill="x")
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")
        body = tk.Frame(self, bg=BG); body.pack(fill="both", expand=True, padx=18, pady=12)

        tk.Label(body, text="English Statement (optional):", bg=BG, fg=ACCENT2,
                 font=("Consolas", 10, "bold")).pack(anchor="w", pady=(8, 2))
        self.eng_var = tk.StringVar()
        tk.Entry(body, textvariable=self.eng_var, bg="#0d0f18", fg=TEXT,
                 font=FONT_MAIN, relief="flat", insertbackground=ACCENT, bd=4).pack(fill="x", ipady=5)
        tk.Label(body, text='  e.g. "Feature A requires Feature B"  or  "A excludes B"',
                 bg=BG, fg=TEXT_DIM, font=("Consolas", 9)).pack(anchor="w")

        tk.Button(body, text="⚡  Auto-Translate to Propositional Logic",
                  command=self._auto_translate, bg=PANEL, fg=YELLOW,
                  font=FONT_MAIN, relief="flat", padx=10, pady=4,
                  cursor="hand2").pack(pady=(10, 4), anchor="w")

        tk.Label(body, text="Propositional Logic (required):", bg=BG, fg=ACCENT2,
                 font=("Consolas", 10, "bold")).pack(anchor="w", pady=(6, 2))
        self.prop_var = tk.StringVar()
        tk.Entry(body, textvariable=self.prop_var, bg="#0d0f18", fg=GREEN,
                 font=("Consolas", 11, "bold"), relief="flat",
                 insertbackground=GREEN, bd=4).pack(fill="x", ipady=6)
        tk.Label(body, text="  e.g.  A → B   |   ¬(A ∧ B)   |   A ∨ B",
                 bg=BG, fg=TEXT_DIM, font=("Consolas", 9)).pack(anchor="w")

        ref = tk.LabelFrame(body, text=" Quick Reference ", bg=BG, fg=TEXT_DIM,
                            font=("Consolas", 9), bd=1, relief="solid")
        ref.pack(fill="x", pady=(14, 4))
        for eng, logic in [("A requires B","A → B"),("A excludes B","¬(A ∧ B)"),
                            ("A or B","A ∨ B"),("A iff B","A ↔ B")]:
            row = tk.Frame(ref, bg=BG); row.pack(fill="x", padx=8, pady=1)
            tk.Label(row, text=f'  "{eng}"', bg=BG, fg=TEXT_DIM, font=("Consolas",9),
                     width=28, anchor="w").pack(side="left")
            tk.Label(row, text=f"→  {logic}", bg=BG, fg=GREEN,
                     font=("Consolas",9), anchor="w").pack(side="left")

        if existing:
            tk.Label(body, text="Existing Constraints:", bg=BG, fg=ACCENT2,
                     font=("Consolas", 10, "bold")).pack(anchor="w", pady=(12, 2))
            for c in existing:
                tk.Label(body, text=f"  {c.propositional or c.english or '(empty)'}",
                         bg=BG, fg=TEXT_DIM, font=FONT_MAIN).pack(anchor="w")

        btn_row = tk.Frame(self, bg=BG); btn_row.pack(fill="x", padx=18, pady=12)
        tk.Button(btn_row, text="✅  Add Constraint", command=self._confirm,
                  bg=PANEL, fg=GREEN, font=FONT_MAIN, relief="flat", padx=14, pady=6,
                  cursor="hand2").pack(side="left", padx=4)
        tk.Button(btn_row, text="⬜  Skip", command=self._skip,
                  bg=PANEL, fg=TEXT_DIM, font=FONT_MAIN, relief="flat", padx=14, pady=6,
                  cursor="hand2").pack(side="left", padx=4)
        tk.Button(btn_row, text="✖  Cancel", command=self.destroy,
                  bg=PANEL, fg=RED, font=FONT_MAIN, relief="flat", padx=14, pady=6,
                  cursor="hand2").pack(side="right", padx=4)

    def _auto_translate(self):
        eng = self.eng_var.get().strip()
        if not eng:
            messagebox.showwarning("Empty", "Enter an English statement first.", parent=self)
            return
        prop = self._translate(eng)
        if prop.startswith("[Manual"):
            messagebox.showinfo("Translation Needed",
                f'Could not auto-translate:\n"{eng}"\n\nPlease enter propositional logic manually.',
                parent=self)
            return
        ok = messagebox.askyesno("Confirm Translation",
            f'Auto-translated:\n\n  "{eng}"\n  →  {prop}\n\nUse this translation?', parent=self)
        if ok:
            self.prop_var.set(prop)

    def _translate(self, eng):
        el = eng.lower()
        m = re.search(r"the\s+(\w+)\s+feature\s+is\s+required\s+to\s+filter\s+the\s+catalog\s+by\s+(\w+)", el)
        if m: return f"By{m.group(2).capitalize()} → {m.group(1).capitalize()}"
        m = re.search(r"(?:[Ff]eature\s+)?(\w+)\s+requires\s+(?:[Ff]eature\s+)?(\w+)", eng, re.IGNORECASE)
        if m: return f"{m.group(1)} → {m.group(2)}"
        m = re.search(r"(?:[Ff]eature\s+)?(\w+)\s+excludes\s+(?:[Ff]eature\s+)?(\w+)", eng, re.IGNORECASE)
        if m: return f"¬({m.group(1)} ∧ {m.group(2)})"
        m = re.search(r"(\w+)\s+implies\s+(\w+)", eng, re.IGNORECASE)
        if m: return f"{m.group(1)} → {m.group(2)}"
        return f"[Manual translation needed] {eng}"

    def _confirm(self):
        prop = self.prop_var.get().strip()
        if not prop:
            messagebox.showwarning("Empty", "Enter propositional logic or click Skip.", parent=self)
            return
        c = Constraint()
        c.english = self.eng_var.get().strip() or None
        c.propositional = prop
        self.result = c
        self.destroy()

    def _skip(self):
        self.result = None
        self.destroy()


class FeatureModelApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Feature Model Analysis Tool  —  FAST NUCES | Formal Methods")
        self.geometry("1400x860")
        self.configure(bg=BG)
        self.minsize(1100, 700)
        self.parser = None; self.translator = None
        self.validator = None; self.mwp_gen = None
        self.check_vars = {}; self.check_widgets = {}
        self._suppress = False
        self.p2_loader = None
        self.p2_file_deps = []; self.p2_feature_deps = []; self.p2_inconsistencies = []
        self._build_ui()

    def _build_ui(self):
        self._style()
        hdr = tk.Frame(self, bg=PANEL, height=52); hdr.pack(fill="x"); hdr.pack_propagate(False)
        tk.Label(hdr, text="⬡  Feature Model Analysis Tool", bg=PANEL, fg=ACCENT,
                 font=("Consolas",15,"bold")).pack(side="left", padx=20, pady=10)
        tk.Label(hdr, text="FAST NUCES — Formal Methods", bg=PANEL, fg=TEXT_DIM,
                 font=FONT_MAIN).pack(side="right", padx=20)
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")
        s = ttk.Style()
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background=PANEL, foreground=TEXT_DIM,
                    font=("Consolas",11,"bold"), padding=[18,8])
        s.map("TNotebook.Tab", background=[("selected",BG)], foreground=[("selected",ACCENT)])
        self.nb = ttk.Notebook(self); self.nb.pack(fill="both", expand=True)
        t1 = tk.Frame(self.nb, bg=BG); t2 = tk.Frame(self.nb, bg=BG)
        self.nb.add(t1, text="  Part 1 — Feature Model Analysis  ")
        self.nb.add(t2, text="  Part 2 — Code Impact Analysis  ")
        self._build_p1(t1); self._build_p2(t2)
        self.status_var = tk.StringVar(value="Ready — load a feature model XML to begin.")
        tk.Label(self, textvariable=self.status_var, bg=BORDER, fg=TEXT_DIM,
                 font=FONT_MAIN, anchor="w", padx=12, pady=4).pack(fill="x", side="bottom")

    def _build_p1(self, par):
        tb = tk.Frame(par, bg=BG, pady=8); tb.pack(fill="x", padx=16)
        self._btn(tb,"📂  Load XML File",    self._load_file,      ACCENT).pack(side="left", padx=4)
        self._btn(tb,"📋  Paste XML",         self._paste_xml,      ACCENT2).pack(side="left", padx=4)
        self._btn(tb,"➕  Add Constraint",    self._add_constraint, YELLOW).pack(side="left", padx=4)
        self._btn(tb,"✅  Validate Config",    self._validate,       GREEN).pack(side="left", padx=4)
        self._btn(tb,"🔢  Generate MWPs",      self._gen_mwps,       ACCENT).pack(side="left", padx=4)
        self._btn(tb,"💾  Export Logic",        self._export_logic,   TEXT_DIM).pack(side="left", padx=4)
        self._btn(tb,"🧹  Clear",              self._clear_all,      RED).pack(side="right", padx=4)

        pane = tk.PanedWindow(par, orient="horizontal", bg=BG, sashwidth=6, bd=0)
        pane.pack(fill="both", expand=True, padx=10, pady=4)

        L = tk.Frame(pane, bg=PANEL); pane.add(L, minsize=290)
        self._sec(L, "FEATURE TREE  [●=mandatory  ○=optional  ⊕=XOR  ⊎=OR]")
        wrap = tk.Frame(L, bg=PANEL); wrap.pack(fill="both", expand=True, padx=8, pady=4)
        self.tree_canvas = tk.Canvas(wrap, bg=PANEL, highlightthickness=0)
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree_canvas.yview)
        self.tree_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); self.tree_canvas.pack(side="left", fill="both", expand=True)
        self.tree_inner = tk.Frame(self.tree_canvas, bg=PANEL)
        win = self.tree_canvas.create_window((0,0), window=self.tree_inner, anchor="nw")
        self.tree_inner.bind("<Configure>", lambda e: self.tree_canvas.configure(
            scrollregion=self.tree_canvas.bbox("all")))
        self.tree_canvas.bind("<Configure>", lambda e: self.tree_canvas.itemconfig(win, width=e.width))

        M = tk.Frame(pane, bg=PANEL); pane.add(M, minsize=360)
        self._sec(M,"PROPOSITIONAL LOGIC RULES"); self.logic_text = self._tb(M, 14)
        self._sec(M,"CROSS-TREE CONSTRAINTS");    self.con_text   = self._tb(M, 7)
        self._sec(M,"VALIDATION RESULT");          self.val_text   = self._tb(M, 10)

        R = tk.Frame(pane, bg=PANEL); pane.add(R, minsize=290)
        self._sec(R,"MINIMUM WORKING PRODUCTS"); self.mwp_text = self._tb(R, expand=True)

    def _build_p2(self, par):
        tb = tk.Frame(par, bg=BG, pady=8); tb.pack(fill="x", padx=16)
        self._btn(tb,"📁  Load Codebase Folder",  self._p2_load,    ACCENT).pack(side="left", padx=4)
        self._btn(tb,"🔍  Extract Dependencies",   self._p2_extract, GREEN).pack(side="left", padx=4)
        self._btn(tb,"⚠  Detect Inconsistencies", self._p2_detect,  RED).pack(side="left", padx=4)
        self._btn(tb,"🎯  Impact Analysis",         self._p2_impact,  YELLOW).pack(side="left", padx=4)
        self._btn(tb,"💾  Export Report",           self._p2_export,  TEXT_DIM).pack(side="left", padx=4)

        pane = tk.PanedWindow(par, orient="horizontal", bg=BG, sashwidth=6, bd=0)
        pane.pack(fill="both", expand=True, padx=10, pady=4)

        L = tk.Frame(pane, bg=PANEL); pane.add(L, minsize=310)
        self._sec(L,"CODEBASE STRUCTURE");     self.p2_struct  = self._tb(L, 10)
        self._sec(L,"FEATURE → FILE MAPPING"); self.p2_mapping = self._tb(L, expand=True)

        M = tk.Frame(pane, bg=PANEL); pane.add(M, minsize=330)
        self._sec(M,"FILE DEPENDENCIES");          self.p2_fdeps    = self._tb(M, 12)
        self._sec(M,"FEATURE-LEVEL DEPENDENCIES"); self.p2_featdeps = self._tb(M, expand=True)

        R = tk.Frame(pane, bg=PANEL); pane.add(R, minsize=310)
        self._sec(R,"INCONSISTENCIES");  self.p2_incons   = self._tb(R, 16)
        self._sec(R,"IMPACT ANALYSIS"); self.p2_impact_t = self._tb(R, expand=True)

    # ── Part 1 Actions ──────────────────────────────────────

    def _load_file(self):
        path = filedialog.askopenfilename(title="Open Feature Model XML",
            filetypes=[("XML","*.xml"),("All","*.*")])
        if not path: return
        try:
            with open(path, encoding="utf-8") as f: xml = f.read()
            self._process_xml(xml)
            self.status_var.set(f"Loaded: {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _paste_xml(self):
        dlg = tk.Toplevel(self); dlg.title("Paste XML"); dlg.configure(bg=BG)
        dlg.geometry("700x520"); dlg.transient(self)
        tk.Label(dlg, text="Paste feature model XML:", bg=BG, fg=TEXT,
                 font=FONT_MAIN).pack(padx=12, pady=8, anchor="w")
        t = scrolledtext.ScrolledText(dlg, bg="#0d0f18", fg=TEXT, font=FONT_MAIN,
                                      relief="flat", height=22, padx=8, pady=8)
        t.pack(fill="both", expand=True, padx=12)
        def go():
            xml = t.get("1.0","end").strip()
            if xml:
                try: self._process_xml(xml); dlg.destroy(); self.status_var.set("XML loaded.")
                except Exception as e: messagebox.showerror("Error", str(e))
        self._btn(dlg,"▶  Parse XML", go, GREEN).pack(pady=10)

    def _process_xml(self, xml):
        self.parser = FeatureModelParser().parse(xml)
        self.translator = LogicTranslator(self.parser)
        self.validator = SATValidator(self.translator)
        self.mwp_gen = MWPGenerator(self.parser, self.validator)
        self._build_tree(); self._init_or_groups(); self._pop_logic(); self._pop_cons()
        self._clr(self.val_text); self._clr(self.mwp_text)

    def _add_constraint(self):
        if not self.parser:
            messagebox.showwarning("No Model", "Load a feature model XML first.")
            return
        dlg = ConstraintDialog(self, self.parser.constraints)
        self.wait_window(dlg)
        if dlg.result is None:
            self.status_var.set("Constraint skipped.")
            return
        c = dlg.result
        self.parser.constraints.append(c)
        # Rebuild with new constraint
        self.translator = LogicTranslator(self.parser)
        self.validator  = SATValidator(self.translator)
        self.mwp_gen    = MWPGenerator(self.parser, self.validator)
        self._pop_logic(); self._pop_cons(); self._clr(self.mwp_text)
        self.status_var.set(f"Constraint added: {c.propositional}")

    def _build_tree(self):
        for w in self.tree_inner.winfo_children(): w.destroy()
        self.check_vars.clear(); self.check_widgets.clear()
        if self.parser and self.parser.root:
            self._render(self.parser.root, self.tree_inner, 0)

    def _init_or_groups(self):
        """Auto-select first OR group member when its parent is already selected.
        Fixes: Payment (mandatory) starts checked but CreditCard/Discount start
        unchecked, causing immediate SAT violation on the very first _quick_check."""
        if not self.parser:
            return
        self._suppress = True
        for g in self.parser.groups:
            if g["type"] == "or":
                pvar = self.check_vars.get(g["parent"].name)
                if pvar and pvar.get():
                    any_sel = any(
                        self.check_vars.get(m.name) and self.check_vars[m.name].get()
                        for m in g["members"]
                    )
                    if not any_sel and g["members"]:
                        self.check_vars[g["members"][0].name].set(True)
        self._suppress = False

    def _render(self, feat, parent_w, depth):
        row = tk.Frame(parent_w, bg=PANEL); row.pack(fill="x", padx=(depth*18,0), pady=1)
        if feat.parent is None:           icon, col = "◈", ACCENT
        elif feat.mandatory:              icon, col = "●", GREEN
        elif feat.group_type == "xor":    icon, col = "⊕", YELLOW
        elif feat.group_type == "or":     icon, col = "⊎", ACCENT2
        else:                             icon, col = "○", TEXT_DIM
        tk.Label(row, text=icon, bg=PANEL, fg=col, font=("Consolas",10)).pack(side="left", padx=(2,4))
        var = tk.BooleanVar(value=(feat.parent is None or feat.mandatory))
        self.check_vars[feat.name] = var
        cb = ttk.Checkbutton(row, text=feat.name, variable=var,
                             state="disabled" if feat.parent is None else "normal",
                             command=lambda f=feat: self._on_check(f))
        cb.pack(side="left"); self.check_widgets[feat.name] = cb
        tags = []
        if feat.parent is None: tags.append("root")
        if feat.mandatory: tags.append("mandatory")
        if feat.group_type: tags.append(feat.group_type.upper())
        if tags:
            tk.Label(row, text=f"[{' | '.join(tags)}]", bg=PANEL, fg=TEXT_DIM,
                     font=("Consolas",8)).pack(side="left", padx=4)
        for ch in feat.children:
            if ch.group_type is None: self._render(ch, parent_w, depth+1)
        for g in (self.parser.groups if self.parser else []):
            if g["parent"] is feat:
                gtype = g["type"].upper(); gclr = YELLOW if gtype=="XOR" else ACCENT2
                gf = tk.Frame(parent_w, bg=PANEL, highlightthickness=1, highlightbackground=gclr)
                gf.pack(fill="x", padx=(depth*18+18,4), pady=3)
                tk.Label(gf, text=f" {gtype} GROUP ", bg=gclr, fg=BG,
                         font=("Consolas",8,"bold")).pack(anchor="w")
                for m in g["members"]: self._render(m, gf, 0)

    def _on_check(self, feat):
        if self._suppress: return
        self._suppress = True
        sel = self.check_vars[feat.name].get()
        # XOR: deselect siblings
        if sel and feat.group_type == "xor":
            for sib in feat.group_members:
                self.check_vars[sib.name].set(False); self._desel(sib)
        # Cross-tree forward propagation: if A selected and A→B, auto-select B
        if sel:
            for c in (self.parser.constraints if self.parser else []):
                m = re.match(r"(\w+)\s*→\s*(\w+)", c.propositional or "")
                if m and m.group(1) == feat.name and m.group(2) in self.check_vars:
                    self.check_vars[m.group(2)].set(True)
                    # Activate OR group of target if nothing selected in it
                    tgt = self.parser.features.get(m.group(2))
                    if tgt:
                        for g in self.parser.groups:
                            if g["parent"] is tgt and not any(
                                    self.check_vars.get(mm.name, tk.BooleanVar()).get()
                                    for mm in g["members"]):
                                self.check_vars[g["members"][0].name].set(True)
        # Prevent deselecting mandatory
        if not sel and feat.mandatory:
            self.check_vars[feat.name].set(True)
            self._show(self.val_text, f"⚠  Cannot deselect mandatory feature: {feat.name}\n", RED)
            self._suppress = False; return
        if not sel: self._desel(feat)
        self._suppress = False
        self._quick_check()

    def _desel(self, feat):
        for ch in feat.children:
            if ch.name in self.check_vars:
                self.check_vars[ch.name].set(False); self._desel(ch)
        for g in (self.parser.groups if self.parser else []):
            if g["parent"] is feat:
                for m in g["members"]:
                    self.check_vars[m.name].set(False); self._desel(m)

    def _quick_check(self):
        if not self.validator: return
        sel = {n for n,v in self.check_vars.items() if v.get()}
        ok, msg = self.validator.validate(sel)
        self._show(self.val_text, msg+"\n", GREEN if ok else RED)

    def _validate(self):
        if not self.validator:
            messagebox.showwarning("No Model","Load XML first."); return
        sel = {n for n,v in self.check_vars.items() if v.get()}
        ok, msg = self.validator.validate(sel)
        lines = [msg, "", f"Selected Features ({len(sel)}):",
                 "  " + ", ".join(sorted(sel))]
        if not ok:
            lines += ["", "Violation Detail:", "  " + self.validator._find_violation(sel)]
        self._show(self.val_text, "\n".join(lines)+"\n", GREEN if ok else RED)

    def _gen_mwps(self):
        if not self.mwp_gen:
            messagebox.showwarning("No Model","Load XML first."); return
        self.status_var.set("Computing MWPs…")
        self._show(self.mwp_text,"⏳ Computing Minimum Working Products…\n", YELLOW)
        def run():
            mwps = self.mwp_gen.generate()
            self.after(0, lambda: self._show_mwps(mwps))
        threading.Thread(target=run, daemon=True).start()

    def _show_mwps(self, mwps):
        if not mwps:
            self._show(self.mwp_text,"No MWPs found.\n", RED); return
        lines = [f"Minimum Working Products Found: {len(mwps)}", "═"*50, "",
                 "Definition: Minimal valid configurations satisfying all mandatory",
                 "constraints and cross-tree constraints, with optional features",
                 "included only when required by constraints.", ""]
        for i,m in enumerate(mwps,1):
            lines.append(f"MWP #{i}  ({len(m)} features):")
            lines.append("  " + ",  ".join(sorted(m))); lines.append("")
        self._show(self.mwp_text, "\n".join(lines), GREEN)
        self.status_var.set(f"MWP complete — {len(mwps)} product(s) found.")

    def _pop_logic(self):
        if not self.translator: return
        lines = ["Propositional Logic Rules:", "═"*50, "",
                 self.translator.get_rules_text(),
                 "", "Variable Map (CNF SAT encoding):"]
        for name,var in self.translator.var_map.items():
            lines.append(f"  x{var:02d}  =  {name}")
        self._show(self.logic_text, "\n".join(lines), TEXT)

    def _pop_cons(self):
        if not self.parser: return
        if not self.parser.constraints:
            self._show(self.con_text,"No cross-tree constraints.\n", TEXT_DIM); return
        lines = [f"Cross-Tree Constraints ({len(self.parser.constraints)}):", "─"*44]
        for i,c in enumerate(self.parser.constraints,1):
            lines.append(f"\nConstraint {i}:")
            if c.english:       lines.append(f"  English : {c.english}")
            if c.boolean_expr:  lines.append(f"  Boolean : {c.boolean_expr}")
            if c.propositional: lines.append(f"  Logic   : {c.propositional}")
        self._show(self.con_text, "\n".join(lines), ACCENT)

    def _export_logic(self):
        if not self.translator:
            messagebox.showwarning("No Model","Load XML first."); return
        path = filedialog.asksaveasfilename(title="Export Logic Rules",
            defaultextension=".txt", filetypes=[("Text","*.txt"),("All","*.*")])
        if not path: return
        lines = ["Feature Model — Propositional Logic Export", "="*60, "",
                 "PROPOSITIONAL LOGIC RULES:", self.translator.get_rules_text(), "",
                 "CROSS-TREE CONSTRAINTS:"]
        for c in self.parser.constraints:
            lines.append(f"  English : {c.english or '—'}")
            lines.append(f"  Logic   : {c.propositional or '—'}"); lines.append("")
        lines += ["", "CNF VARIABLE MAP:"]
        for name,var in self.translator.var_map.items():
            lines.append(f"  x{var:02d} = {name}")
        mwps = self.mwp_gen.generate() if self.mwp_gen else []
        lines += ["", f"MINIMUM WORKING PRODUCTS ({len(mwps)}):"]
        for i,m in enumerate(mwps,1):
            lines.append(f"  MWP #{i}: {', '.join(sorted(m))}")
        with open(path,"w",encoding="utf-8") as f: f.write("\n".join(lines))
        messagebox.showinfo("Exported", f"Saved to:\n{path}")

    def _clear_all(self):
        self.parser = self.translator = self.validator = self.mwp_gen = None
        for w in self.tree_inner.winfo_children(): w.destroy()
        self.check_vars.clear(); self.check_widgets.clear()
        for t in [self.logic_text,self.con_text,self.val_text,self.mwp_text]: self._clr(t)
        self.status_var.set("Cleared.")

    # ── Part 2 Actions ──────────────────────────────────────

    def _p2_load(self):
        from part2_core import CodebaseLoader, FEATURE_FILE_MAPPING, MAPPING_JUSTIFICATIONS
        # Ask user: folder or Git URL?
        dlg = tk.Toplevel(self); dlg.title("Load Codebase"); dlg.configure(bg=BG)
        dlg.geometry("580x220"); dlg.transient(self); dlg.grab_set()
        choice = tk.StringVar(value="folder")
        tk.Label(dlg, text="  Select codebase source:", bg=BG, fg=ACCENT,
                 font=("Consolas",12,"bold")).pack(anchor="w", padx=16, pady=(14,4))
        tk.Radiobutton(dlg, text="📁  Local folder", variable=choice, value="folder",
                       bg=BG, fg=TEXT, font=FONT_MAIN, selectcolor=PANEL,
                       activebackground=BG).pack(anchor="w", padx=28)
        tk.Radiobutton(dlg, text="🌐  Git repository URL", variable=choice, value="git",
                       bg=BG, fg=TEXT, font=FONT_MAIN, selectcolor=PANEL,
                       activebackground=BG).pack(anchor="w", padx=28)
        git_var = tk.StringVar()
        git_frame = tk.Frame(dlg, bg=BG); git_frame.pack(fill="x", padx=28, pady=6)
        tk.Label(git_frame, text="Git URL:", bg=BG, fg=TEXT_DIM, font=FONT_MAIN).pack(side="left")
        tk.Entry(git_frame, textvariable=git_var, bg="#0d0f18", fg=TEXT, font=FONT_MAIN,
                 relief="flat", width=40, bd=3).pack(side="left", padx=6, ipady=3)
        result = [None]
        def go():
            result[0] = (choice.get(), git_var.get().strip()); dlg.destroy()
        tk.Button(dlg, text="▶  Load", command=go, bg=PANEL, fg=GREEN,
                  font=FONT_MAIN, relief="flat", padx=14, pady=5, cursor="hand2").pack(pady=10)
        self.wait_window(dlg)
        if result[0] is None: return
        src_type, git_url = result[0]
        self.p2_loader = CodebaseLoader()
        if src_type == "git":
            if not git_url:
                messagebox.showwarning("Empty","Enter a Git URL."); return
            try:
                import subprocess, tempfile, shutil
                self.status_var.set("Cloning repository…"); self.update()
                tmpdir = tempfile.mkdtemp()
                proc = subprocess.run(["git","clone","--depth","1", git_url, tmpdir],
                                      capture_output=True, text=True, timeout=60)
                if proc.returncode != 0:
                    messagebox.showerror("Git Error", proc.stderr[:400]); return
                self.p2_loader.load_folder(tmpdir)
                path = f"[Git] {git_url}"
            except Exception as e:
                messagebox.showerror("Error", str(e)); return
        else:
            path = filedialog.askdirectory(title="Select Codebase Folder")
            if not path: return
            self.p2_loader.load_folder(path)
        n = len(self.p2_loader.files)
        if n == 0: messagebox.showwarning("Empty","No source files found."); return
        lines = [f"Codebase Root: {path}", f"Total Files: {n}", "─"*50]
        for f in sorted(self.p2_loader.files):
            lines.append("  "*f.count("/") + "📄 " + f)
        self._show(self.p2_struct, "\n".join(lines), TEXT)
        mlines = ["Feature  →  Implementation Files", "═"*60,
                  "(Justified by code functionality)", ""]
        for feat,files in FEATURE_FILE_MAPPING.items():
            just = MAPPING_JUSTIFICATIONS.get(feat,"")
            mlines.append(f"▸ {feat}:")
            for f in files: mlines.append(f"    📄 {f}")
            mlines.append(f"    ↳ {just}"); mlines.append("")
        self._show(self.p2_mapping, "\n".join(mlines), ACCENT)
        self.status_var.set(f"Codebase loaded: {n} files.")

    def _p2_extract(self):
        if not self.p2_loader:
            messagebox.showwarning("No Codebase","Load a folder first."); return
        from part2_core import DependencyExtractor, FeatureDependencyDeriver
        self.p2_file_deps = DependencyExtractor(self.p2_loader).extract()
        lines = [f"File-Level Dependencies: {len(self.p2_file_deps)}", "─"*60,
                 "(source → target  with evidence line)", ""]
        for d in self.p2_file_deps:
            lines.append(f"  {d.source}  →  {d.target}")
            lines.append(f"    Line {d.line_number}: {d.evidence}"); lines.append("")
        self._show(self.p2_fdeps, "\n".join(lines), TEXT)

        self.p2_feature_deps = FeatureDependencyDeriver(self.p2_file_deps).derive()
        flines = [f"Feature-Level Dependencies: {len(self.p2_feature_deps)}", "─"*60,
                  "Rule: if file(A) → file(B) then Feature(A) → Feature(B)", ""]
        for fd in self.p2_feature_deps:
            flines.append(f"  {fd.source_feature}  →  {fd.target_feature}")
            flines.append(f"    via {fd.via_source_file} → {fd.via_target_file}")
            flines.append(f"    {fd.evidence}"); flines.append("")
        self._show(self.p2_featdeps, "\n".join(flines), ACCENT2)
        self.status_var.set(f"{len(self.p2_file_deps)} file deps, "
                            f"{len(self.p2_feature_deps)} feature deps extracted.")

    def _p2_detect(self):
        if not self.p2_feature_deps:
            messagebox.showwarning("Extract First","Run extraction first."); return
        if not self.parser:
            messagebox.showwarning("No FM","Load a feature model in Part 1 first."); return
        from part2_core import InconsistencyDetector
        self.p2_inconsistencies = InconsistencyDetector(self.p2_feature_deps, self.parser).detect()
        lines = [f"Inconsistencies Detected: {len(self.p2_inconsistencies)}", "═"*60, ""]
        KINDS = {"hidden":"⚠  HIDDEN DEPENDENCY","missing":"⚠  MISSING CONSTRAINT",
                 "incorrect":"⚠  INCORRECT CONSTRAINT"}
        for i,inc in enumerate(self.p2_inconsistencies,1):
            lines.append(f"[{i}] {KINDS.get(inc.kind, inc.kind.upper())}")
            lines.append(f"    {inc.source_feature}  →  {inc.target_feature}")
            lines.append(f"\n    Description:\n    {inc.description}")
            lines.append(f"\n    Evidence:")
            for ln in inc.evidence.splitlines(): lines.append(f"      {ln}")
            lines.append(f"\n    Resolution:\n      {inc.resolution}")
            lines.append("\n"+"─"*60)
        self._show(self.p2_incons, "\n".join(lines), RED)
        self.status_var.set(f"Detection complete — {len(self.p2_inconsistencies)} inconsistency(s).")

    def _p2_impact(self):
        if not self.p2_file_deps:
            messagebox.showwarning("Extract First","Run extraction first."); return
        if not self.check_vars:
            messagebox.showwarning("No Selection","Select features in Part 1 first."); return
        from part2_core import ImpactAnalyser
        sel = {n for n,v in self.check_vars.items() if v.get()}
        res = ImpactAnalyser(self.p2_file_deps).analyse(sel)
        lines = ["Feature Selection Impact Analysis", "═"*50, "",
                 f"Selected Features ({len(res['selected_features'])}):",
                 *[f"  ✔  {f}" for f in sorted(res["selected_features"])],
                 "", f"Direct Implementation Files ({len(res['direct_files'])}):",
                 *[f"  📄 {f}" for f in sorted(res["direct_files"])],
                 "", f"Indirect Dependencies ({len(res['indirect_files'])}):",
                 "(Transitively required at runtime)",
                 *[f"  ↳  {f}" for f in sorted(res["indirect_files"])],
                 "", f"Total Impacted Files: {len(res['all_impacted'])}"]
        self._show(self.p2_impact_t, "\n".join(lines), GREEN)
        self.status_var.set(f"Impact: {len(res['all_impacted'])} files affected.")

    def _p2_export(self):
        if not self.p2_file_deps:
            messagebox.showwarning("No Data","Run extraction first."); return
        path = filedialog.asksaveasfilename(title="Export Analysis Report",
            defaultextension=".txt", filetypes=[("Text","*.txt"),("All","*.*")])
        if not path: return
        lines = ["Feature-to-Code Impact Analysis Report", "="*60, "", "FILE DEPENDENCIES:"]
        for d in self.p2_file_deps:
            lines.append(f"  {d.source} → {d.target}  (line {d.line_number}: {d.evidence})")
        lines += ["", "FEATURE-LEVEL DEPENDENCIES:"]
        for fd in self.p2_feature_deps:
            lines.append(f"  {fd.source_feature} → {fd.target_feature}")
            lines.append(f"    via {fd.via_source_file} → {fd.via_target_file}")
            lines.append(f"    {fd.evidence}")
        lines += ["", "INCONSISTENCIES:"]
        for inc in self.p2_inconsistencies:
            lines.append(f"  [{inc.kind.upper()}] {inc.source_feature} → {inc.target_feature}")
            lines.append(f"    {inc.description}")
            lines.append(f"    Resolution: {inc.resolution}")
        with open(path,"w",encoding="utf-8") as f: f.write("\n".join(lines))
        messagebox.showinfo("Exported", f"Report saved to:\n{path}")

    # ── UI Helpers ───────────────────────────────────────────

    def _style(self):
        s = ttk.Style(self); s.theme_use("clam")
        s.configure("TCheckbutton", background=PANEL, foreground=TEXT, font=FONT_MAIN, focuscolor=PANEL)
        s.map("TCheckbutton", foreground=[("active",ACCENT),("disabled",TEXT_DIM)],
              background=[("active",PANEL)])
        s.configure("Vertical.TScrollbar", background=BORDER, troughcolor=PANEL,
                    bordercolor=PANEL, arrowcolor=TEXT_DIM)

    def _btn(self, par, text, cmd, color):
        return tk.Button(par, text=text, command=cmd, bg=PANEL, fg=color, font=FONT_MAIN,
                         relief="flat", padx=12, pady=5, activebackground=BORDER,
                         activeforeground=color, cursor="hand2", bd=1,
                         highlightthickness=1, highlightbackground=color)

    def _sec(self, par, text):
        tk.Frame(par, bg=BG, height=1).pack(fill="x", pady=(6,0))
        tk.Label(par, text=f"  {text}", bg=BG, fg=ACCENT2,
                 font=("Consolas",9,"bold"), anchor="w").pack(fill="x")
        tk.Frame(par, bg=BORDER, height=1).pack(fill="x")

    def _tb(self, par, height=10, expand=False):
        t = scrolledtext.ScrolledText(par, bg="#0d0f18", fg=TEXT, font=FONT_MAIN, relief="flat",
                                      height=height, padx=8, pady=8, insertbackground=ACCENT,
                                      selectbackground=ACCENT, wrap="word", state="disabled", bd=0)
        t.pack(fill="both", expand=expand, padx=8, pady=4); return t

    def _show(self, w, text, color=TEXT):
        w.config(state="normal"); w.delete("1.0","end"); w.insert("end", text)
        w.tag_add("c","1.0","end"); w.tag_config("c", foreground=color); w.config(state="disabled")

    def _clr(self, w):
        w.config(state="normal"); w.delete("1.0","end"); w.config(state="disabled")


if __name__ == "__main__":
    FeatureModelApp().mainloop()
