"""
Q1 – Requirements Dependency Graph Analysis
Documents:
  1. Grid 3D Application SRS (2005)
  2. Microcare VMUS SRS (2005)

Usage:
    python q1_graph_analysis.py

Outputs (in ./output/):
  - grid3d_graph.png
  - microcare_graph.png
  - q1_results.txt   (full tabular results + interpretation, printable)
"""

import os
import textwrap
import networkx as nx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

OUTPUT_DIR = "output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
#  DOCUMENT 1 – Grid 3D Application SRS
# ─────────────────────────────────────────────────────────────────────────────

GRID_NODES = {
    "G01": "Data Format",
    "G02": "Plot Points",
    "G03": "Axis Labels",
    "G04": "Colour by Cluster",
    "G05": "Handle 2000 Pts",
    "G06": "Single-Click Name",
    "G07": "Double-Click Detail",
    "G08": "Multi-Point Select",
    "G09": "Grid Orientation",
    "G10": "Point Size",
    "G11": "Clear Axis Label",
    "G12": "Startup Time",
    "G13": "Interaction Delay",
    "G14": "Orientation Speed",
    "G15": "Printable Colours",
}

# Edge rule: A → B  means "B depends on A"
# B cannot function correctly without A being implemented first.
# Dependencies identified from:
#   - Data-format preconditions (G01 must exist before points can be plotted)
#   - Capacity preconditions   (G05 must be satisfied before plotting works)
#   - Functional prerequisites (G02 must work before any interaction req)
#   - Refinement links         (G03 → G11 : clear labelling refines axis labels)
#   - NF constraints on F reqs (G09 must work before orientation speed is measurable)
GRID_EDGES = [
    ("G01", "G02"),   # Data format → Plot Points
    ("G01", "G03"),   # Data format → Axis Labels
    ("G01", "G04"),   # Data format → Colour by Cluster
    ("G05", "G02"),   # Handle 2000 Pts → Plot Points
    ("G05", "G12"),   # Handle 2000 Pts → Startup Time
    ("G02", "G06"),   # Plot Points → Single-Click Name
    ("G02", "G07"),   # Plot Points → Double-Click Detail
    ("G02", "G08"),   # Plot Points → Multi-Point Select
    ("G02", "G09"),   # Plot Points → Grid Orientation
    ("G02", "G10"),   # Plot Points → Point Size
    ("G03", "G11"),   # Axis Labels → Clear Axis Label
    ("G04", "G15"),   # Colour by Cluster → Printable Colours
    ("G06", "G13"),   # Single-Click Name → Interaction Delay
    ("G09", "G14"),   # Grid Orientation → Orientation Speed
]

# ─────────────────────────────────────────────────────────────────────────────
#  DOCUMENT 2 – Microcare VMUS SRS
# ─────────────────────────────────────────────────────────────────────────────

VMUS_NODES = {
    "V01": "Security & Privileges",
    "V02": "Database",
    "V03": "Voucher Creation",
    "V04": "Distributor Master",
    "V05": "Sales Team Master",
    "V06": "Marketing / Sales",
    "V07": "Distribution Tx",
    "V08": "VSP Master",
    "V09": "VSP Staff Master",
    "V10": "Claim Submission",
    "V11": "Claim Entry",
    "V12": "Claim Entry Detail",
    "V13": "Claim Processing",
    "V14": "Sales Return",
    "V15": "Client Feedback",
    "V16": "Reports",
}

# Edge rule: A → B  means "B depends on A"
# Dependencies identified from:
#   - Process-flow (Voucher must exist before it can be sold → V03 → V06)
#   - Master-data preconditions (Distributor Master feeds Distribution Tx)
#   - Module containment (Distribution Tx is a sub-module of Marketing/Sales)
#   - Security cross-cut (V01 governs creation/editing in every module)
#   - Database underlies claim detail, reports and feedback
#   - Claim pipeline: VSP → Staff → Submission → Detail → Processing → outputs
VMUS_EDGES = [
    ("V03", "V06"),   # Voucher Creation → Marketing/Sales
    ("V03", "V11"),   # Voucher Creation → Claim Entry
    ("V03", "V14"),   # Voucher Creation → Sales Return
    ("V04", "V07"),   # Distributor Master → Distribution Tx
    ("V05", "V07"),   # Sales Team Master → Distribution Tx
    ("V06", "V11"),   # Marketing/Sales → Claim Entry
    ("V07", "V14"),   # Distribution Tx → Sales Return
    ("V07", "V16"),   # Distribution Tx → Reports
    ("V08", "V09"),   # VSP Master → VSP Staff Master
    ("V08", "V10"),   # VSP Master → Claim Submission
    ("V09", "V12"),   # VSP Staff Master → Claim Entry Detail
    ("V10", "V12"),   # Claim Submission → Claim Entry Detail
    ("V11", "V12"),   # Claim Entry → Claim Entry Detail
    ("V12", "V13"),   # Claim Entry Detail → Claim Processing
    ("V13", "V15"),   # Claim Processing → Client Feedback
    ("V13", "V16"),   # Claim Processing → Reports
    ("V14", "V16"),   # Sales Return → Reports
    ("V02", "V12"),   # Database → Claim Entry Detail
    ("V02", "V15"),   # Database → Client Feedback
    ("V02", "V16"),   # Database → Reports
    ("V01", "V03"),   # Security → Voucher Creation
    ("V01", "V06"),   # Security → Marketing/Sales
    ("V01", "V11"),   # Security → Claim Entry
    ("V01", "V14"),   # Security → Sales Return
    ("V01", "V15"),   # Security → Client Feedback
    ("V01", "V16"),   # Security → Reports
]


# ─────────────────────────────────────────────────────────────────────────────
#  GRAPH BUILDER & METRICS
# ─────────────────────────────────────────────────────────────────────────────

def build_graph(nodes: dict, edges: list) -> nx.DiGraph:
    G = nx.DiGraph()
    G.add_nodes_from(nodes.keys())
    G.add_edges_from(edges)
    return G


def compute_metrics(G: nx.DiGraph, nodes: dict) -> list[dict]:
    bet = nx.betweenness_centrality(G, normalized=True)
    clo = nx.closeness_centrality(G)
    rows = []
    for nid, label in nodes.items():
        rows.append({
            "id":        nid,
            "label":     label,
            "in":        G.in_degree(nid),
            "out":       G.out_degree(nid),
            "degree":    G.degree(nid),
            "between":   round(bet.get(nid, 0), 4),
            "closeness": round(clo.get(nid, 0), 4),
        })
    return rows


# ─────────────────────────────────────────────────────────────────────────────
#  GRAPH VISUALISER
# ─────────────────────────────────────────────────────────────────────────────

def draw_graph(G: nx.DiGraph, nodes: dict, title: str, filepath: str):
    """Draw a directed requirements graph and save to filepath."""
    fig, ax = plt.subplots(figsize=(14, 7))
    fig.patch.set_facecolor("#F8F9FA")
    ax.set_facecolor("#F8F9FA")

    # Layout
    pos = nx.spring_layout(G, seed=42, k=2.2)

    # Node colours by role
    color_map = []
    for n in G.nodes():
        if G.in_degree(n) == 0:
            color_map.append("#2E86AB")   # blue  = source (root)
        elif G.out_degree(n) == 0:
            color_map.append("#E84855")   # red   = sink (leaf)
        else:
            color_map.append("#3BB273")   # green = intermediate

    # Node sizes proportional to total degree (min 800)
    sizes = [max(800, G.degree(n) * 350) for n in G.nodes()]

    # Draw edges
    nx.draw_networkx_edges(
        G, pos, ax=ax,
        edge_color="#888888",
        arrows=True,
        arrowstyle="-|>",
        arrowsize=18,
        width=1.4,
        connectionstyle="arc3,rad=0.08",
        min_source_margin=18,
        min_target_margin=18,
    )

    # Draw nodes
    nx.draw_networkx_nodes(
        G, pos, ax=ax,
        node_color=color_map,
        node_size=sizes,
        alpha=0.92,
    )

    # Labels: short ID + label on two lines
    labels = {n: f"{n}\n{nodes[n]}" for n in G.nodes()}
    nx.draw_networkx_labels(
        G, pos, labels=labels, ax=ax,
        font_size=7, font_color="white", font_weight="bold",
    )

    # Legend
    legend_handles = [
        mpatches.Patch(color="#2E86AB", label="Source node (in-degree = 0)"),
        mpatches.Patch(color="#3BB273", label="Intermediate node"),
        mpatches.Patch(color="#E84855", label="Sink node (out-degree = 0)"),
    ]
    ax.legend(handles=legend_handles, loc="lower left", fontsize=9,
              framealpha=0.85)

    ax.set_title(title, fontsize=14, fontweight="bold", pad=14)
    ax.axis("off")
    plt.tight_layout()
    plt.savefig(filepath, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {filepath}")


# ─────────────────────────────────────────────────────────────────────────────
#  TEXT REPORT WRITER
# ─────────────────────────────────────────────────────────────────────────────

SEP  = "=" * 90
SEP2 = "-" * 90

def fmt_edge_list(edges: list, nodes: dict) -> str:
    lines = ["Source, Target", "Source_ID, Target_ID, Source_Label, Target_Label"]
    lines.append("")
    for s, t in edges:
        lines.append(f"{s}, {t}")
    lines.append("")
    lines.append("Detailed format:")
    lines.append("Source,Target,Source_Label,Target_Label")
    for s, t in edges:
        lines.append(f"{s},{t},{nodes[s]},{nodes[t]}")
    return "\n".join(lines)


def fmt_table(rows: list[dict]) -> str:
    h = (f"{'Node ID':<8} {'Label':<22} {'In':>4} {'Out':>4} "
         f"{'Degree':>6} {'Betweenness':>13} {'Closeness':>11}")
    lines = [SEP2, h, SEP2]
    for r in rows:
        lines.append(
            f"{r['id']:<8} {r['label']:<22} {r['in']:>4} {r['out']:>4} "
            f"{r['degree']:>6} {r['between']:>13.4f} {r['closeness']:>11.4f}"
        )
    lines.append(SEP2)
    return "\n".join(lines)


GRID_INTERPRETATION = """\
INTERPRETATION – Grid 3D Application

G02 (Plot Points) is the central hub with the highest total degree.
It sits between the foundational data/capacity requirements and all
user-interaction and non-functional requirements. Its betweenness
centrality is the highest in the graph because nearly every shortest
path from a root requirement to a leaf requirement passes through it.

G01 (Data Format) and G05 (Handle 2000 Points) are pure source nodes
(in-degree = 0). They represent the baseline constraints that must be
in place before any functional capability can be built. G01 drives
three downstream requirements; G05 drives two.

The six leaf requirements (G07, G08, G10, G11, G12–G15) are all
non-functional or refinement requirements. They have out-degree = 0,
meaning nothing else depends on them – they are measurable acceptance
criteria for the functional requirements they refine.

The graph topology is a shallow, two-level star centred on G02,
reflecting a small, tightly scoped, single-purpose visualisation tool
with a thin requirement hierarchy.
"""

VMUS_INTERPRETATION = """\
INTERPRETATION – Microcare Voucher Management Unit System (VMUS)

V01 (Security & Privileges) is the only node with out-degree 6. It
governs all major modules; no module can be created, edited, or
executed without an authorised user. Despite this power, its closeness
is 0.0 because no requirement depends on it upstream – it is a pure
policy source node.

V16 (Reports) has the highest in-degree (6) and closeness centrality.
It aggregates outputs from Distribution Tx, Sales Return, Claim
Processing, the Database and Security, making it the system's primary
information-output sink.

V12 (Claim Entry Detail) has the highest betweenness centrality. It
lies at the convergence of three upstream paths (VSP Staff, Claim
Submission, Database) and is the sole gateway into Claim Processing,
making it a critical bottleneck. Any failure or delay here propagates
to both Reports and Client Feedback.

V13 (Claim Processing) is the second most important intermediary: it
bridges the claim pipeline to two terminal outputs (V15 Client Feedback
and V16 Reports).

V04 (Distributor Master), V05 (Sales Team Master), V08 (VSP Master),
V01 and V02 are all source nodes (in-degree = 0), representing master
data and infrastructure that the rest of the system depends upon.

The VMUS graph is significantly more complex than Grid 3D (26 edges vs
14), with a layered pipeline structure rather than a simple star,
reflecting its enterprise-level, multi-stakeholder workflow.
"""


def write_report(path: str,
                 g1: nx.DiGraph, rows1: list, edges1: list, nodes1: dict,
                 g2: nx.DiGraph, rows2: list, edges2: list, nodes2: dict):
    with open(path, "w") as f:

        def w(line=""): f.write(line + "\n")

        w(SEP)
        w("QUESTION 1 – REQUIREMENTS DEPENDENCY GRAPH ANALYSIS")
        w("Selected documents:  1. Grid 3D Application SRS (2005)")
        w("                     2. Microcare VMUS SRS (2005)")
        w(SEP)
        w()

        # ── DOCUMENT 1 ──────────────────────────────────────────────────────
        w(SEP)
        w("DOCUMENT 1 – Grid 3D Application SRS")
        w(SEP)
        w()
        w("── Define Nodes ─────────────────────────────────────────────────")
        w(f"{'Node ID':<8} Requirement Label")
        w(SEP2)
        for nid, lbl in nodes1.items():
            w(f"{nid:<8} {lbl}")
        w()

        w("── Rule to Identify Dependency ──────────────────────────────────")
        w("Graph type: DIRECTED")
        w()
        w('An edge (A, B) means "A depends on B".')
        w("A cannot function correctly without B being in place first.")
        w("Dependencies were identified by:")
        w("  • Data-format preconditions  – G01 must exist before points can")
        w("    be plotted (G02), axis labels generated (G03) or colour")
        w("    applied (G04).")
        w("  • Capacity preconditions     – G05 (Handle 2000 Points) must be")
        w("    satisfied before G02 (Plot Points) and G12 (Startup Time)")
        w("    are achievable.")
        w("  • Functional prerequisites   – G02 (Plot Points) must work")
        w("    before any mouse-interaction requirement (G06–G10) can exist.")
        w("  • Refinement/NF constraints  – G03 → G11, G04 → G15,")
        w("    G06 → G13, G09 → G14 (NF requirements refine their parent")
        w("    functional requirement).")
        w()

        w("── Edge List (CSV format) ────────────────────────────────────────")
        w(fmt_edge_list(edges1, nodes1))
        w()

        w("── Graph image saved to: output/grid3d_graph.png ────────────────")
        w()

        w("── Results ──────────────────────────────────────────────────────")
        w(f"Nodes: {g1.number_of_nodes()}    Edges: {g1.number_of_edges()}")
        w()
        w(fmt_table(rows1))
        w()

        w("── Interpretation ───────────────────────────────────────────────")
        w(GRID_INTERPRETATION)

        # ── DOCUMENT 2 ──────────────────────────────────────────────────────
        w(SEP)
        w("DOCUMENT 2 – Microcare VMUS SRS")
        w(SEP)
        w()
        w("── Define Nodes ─────────────────────────────────────────────────")
        w(f"{'Node ID':<8} Requirement Label")
        w(SEP2)
        for nid, lbl in nodes2.items():
            w(f"{nid:<8} {lbl}")
        w()

        w("── Rule to Identify Dependency ──────────────────────────────────")
        w("Graph type: DIRECTED")
        w()
        w('An edge (A, B) means "A depends on B".')
        w("A cannot function correctly without B being in place first.")
        w("Dependencies were identified by:")
        w("  • Process-flow       – Voucher must exist before distribution")
        w("    (V03 → V06) and before a claim can be entered (V03 → V11).")
        w("  • Master-data prereqs– Distributor/Sales masters must exist")
        w("    before Distribution Transactions can be recorded.")
        w("  • Module containment – Distribution Tx is a sub-module of")
        w("    Marketing/Sales; Claim Detail belongs to Claim Entry pipeline.")
        w("  • Security cross-cut – V01 governs creation/editing in every")
        w("    module → V01 → V03, V06, V11, V14, V15, V16.")
        w("  • Database underlay  – V02 stores all claim, report and")
        w("    feedback data → V02 → V12, V15, V16.")
        w("  • Claim pipeline     – VSP Master → Staff → Submission →")
        w("    Detail → Processing → Reports / Feedback.")
        w()

        w("── Edge List (CSV format) ────────────────────────────────────────")
        w(fmt_edge_list(edges2, nodes2))
        w()

        w("── Graph image saved to: output/microcare_graph.png ─────────────")
        w()

        w("── Results ──────────────────────────────────────────────────────")
        w(f"Nodes: {g2.number_of_nodes()}    Edges: {g2.number_of_edges()}")
        w()
        w(fmt_table(rows2))
        w()

        w("── Interpretation ───────────────────────────────────────────────")
        w(VMUS_INTERPRETATION)

        w(SEP)
        w("END OF QUESTION 1")
        w(SEP)

    print(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    print("\n=== Q1 – Requirements Graph Analysis ===\n")

    # Build graphs
    G1 = build_graph(GRID_NODES, GRID_EDGES)
    G2 = build_graph(VMUS_NODES, VMUS_EDGES)

    # Compute metrics
    rows1 = compute_metrics(G1, GRID_NODES)
    rows2 = compute_metrics(G2, VMUS_NODES)

    # Print summary to console
    print("Document 1 – Grid 3D")
    print(f"  Nodes: {G1.number_of_nodes()}  |  Edges: {G1.number_of_edges()}")
    print(fmt_table(rows1))

    print("\nDocument 2 – Microcare VMUS")
    print(f"  Nodes: {G2.number_of_nodes()}  |  Edges: {G2.number_of_edges()}")
    print(fmt_table(rows2))

    # Draw & save graphs
    print("\nGenerating graph images...")
    draw_graph(G1, GRID_NODES,
               "Document 1 – Grid 3D Application\nRequirements Dependency Graph (Directed)",
               os.path.join(OUTPUT_DIR, "grid3d_graph.png"))

    draw_graph(G2, VMUS_NODES,
               "Document 2 – Microcare VMUS\nRequirements Dependency Graph (Directed)",
               os.path.join(OUTPUT_DIR, "microcare_graph.png"))

    # Write full text report
    print("\nWriting text report...")
    write_report(
        os.path.join(OUTPUT_DIR, "q1_results.txt"),
        G1, rows1, GRID_EDGES, GRID_NODES,
        G2, rows2, VMUS_EDGES, VMUS_NODES,
    )

    print("\nDone! All outputs are in the ./output/ folder.")
    print("  output/grid3d_graph.png")
    print("  output/microcare_graph.png")
    print("  output/q1_results.txt")


if __name__ == "__main__":
    main()
